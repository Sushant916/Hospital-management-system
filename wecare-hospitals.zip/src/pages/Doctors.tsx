import React, { useState, useMemo } from 'react';
import { Doctor, Department, PageId } from '../types/hospital';
import { DOCTORS, DEPARTMENTS } from '../data/hospitalData';
import { DoctorCard } from '../components/DoctorCard';
import { Search, Filter, Stethoscope, Video, Star, Award, RotateCcw } from 'lucide-react';

interface DoctorsProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: (doctorId: string, departmentId: string) => void;
  onViewDoctorProfile: (doctor: Doctor) => void;
  initialDepartmentFilter?: string;
}

export const Doctors: React.FC<DoctorsProps> = ({
  onNavigate,
  onOpenBooking,
  onViewDoctorProfile,
  initialDepartmentFilter
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDeptId, setSelectedDeptId] = useState<string>(initialDepartmentFilter || 'all');
  const [experienceFilter, setExperienceFilter] = useState<'all' | '10+' | '15+' | '20+'>('all');
  const [telehealthOnly, setTelehealthOnly] = useState(false);
  const [sortBy, setSortBy] = useState<'rating' | 'experience' | 'fee-low' | 'fee-high'>('rating');

  const filteredDoctors = useMemo(() => {
    return DOCTORS.filter(doc => {
      // Department filter
      if (selectedDeptId !== 'all' && doc.departmentId !== selectedDeptId) {
        return false;
      }

      // Telehealth filter
      if (telehealthOnly && !doc.telehealthAvailable) {
        return false;
      }

      // Experience filter
      if (experienceFilter === '10+' && doc.experienceYears < 10) return false;
      if (experienceFilter === '15+' && doc.experienceYears < 15) return false;
      if (experienceFilter === '20+' && doc.experienceYears < 20) return false;

      // Text search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = doc.name.toLowerCase().includes(q);
        const matchTitle = doc.title.toLowerCase().includes(q);
        const matchDept = doc.departmentName.toLowerCase().includes(q);
        const matchSpec = doc.specializations.some(s => s.toLowerCase().includes(q));
        const matchBio = doc.bio.toLowerCase().includes(q);
        return matchName || matchTitle || matchDept || matchSpec || matchBio;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'experience') return b.experienceYears - a.experienceYears;
      if (sortBy === 'fee-low') return a.consultationFee - b.consultationFee;
      if (sortBy === 'fee-high') return b.consultationFee - a.consultationFee;
      return 0;
    });
  }, [searchQuery, selectedDeptId, experienceFilter, telehealthOnly, sortBy]);

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedDeptId('all');
    setExperienceFilter('all');
    setTelehealthOnly(false);
    setSortBy('rating');
  };

  return (
    <div className="space-y-12 pb-16">
      {/* HEADER */}
      <section className="bg-slate-900 text-white py-14 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-2xl space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-teal-400">
              Medical Faculty & Staff
            </span>
            <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-white">
              Consult With Leading Specialists
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Find board-certified physicians, surgeons, and department directors at WeCare Hospitals. Schedule in-person outpatient appointments or secure video telehealth consultations.
            </p>
          </div>

          {/* Search Bar */}
          <div className="mt-8 bg-white/10 backdrop-blur-md p-3.5 rounded-xl border border-white/20">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-300 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by physician name, clinical specialty, or condition (e.g., knee, stroke, valve, tumor)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white text-slate-900 placeholder:text-slate-500 rounded-lg text-xs font-medium focus:outline-teal-500"
              />
            </div>
          </div>
        </div>
      </section>

      {/* FILTER & SORT CONTROLS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 uppercase tracking-wider">
              <Filter className="w-4 h-4 text-teal-600" />
              <span>Filter Physicians</span>
            </div>
            
            {(selectedDeptId !== 'all' || experienceFilter !== 'all' || telehealthOnly || searchQuery) && (
              <button
                onClick={resetFilters}
                className="text-xs font-semibold text-rose-600 hover:text-rose-700 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset All Filters</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Department Filter */}
            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-500 mb-1">
                Clinical Department
              </label>
              <select
                value={selectedDeptId}
                onChange={(e) => setSelectedDeptId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:border-teal-600"
              >
                <option value="all">All Departments ({DOCTORS.length} Doctors)</option>
                {DEPARTMENTS.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>

            {/* Experience Filter */}
            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-500 mb-1">
                Clinical Seniority
              </label>
              <select
                value={experienceFilter}
                onChange={(e) => setExperienceFilter(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:border-teal-600"
              >
                <option value="all">Any Experience Level</option>
                <option value="10+">10+ Years Practice</option>
                <option value="15+">15+ Years Practice</option>
                <option value="20+">20+ Years Practice (Chief / Senior)</option>
              </select>
            </div>

            {/* Sort Order */}
            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-500 mb-1">
                Sort Results By
              </label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:bg-white focus:border-teal-600"
              >
                <option value="rating">Highest Rated (Patient Score)</option>
                <option value="experience">Most Experienced First</option>
                <option value="fee-low">Consultation Fee: Low to High</option>
                <option value="fee-high">Consultation Fee: High to Low</option>
              </select>
            </div>

            {/* Telehealth Toggle */}
            <div className="flex items-center sm:items-end">
              <label className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 w-full text-xs font-medium text-slate-700 cursor-pointer hover:bg-slate-100">
                <input
                  type="checkbox"
                  checked={telehealthOnly}
                  onChange={(e) => setTelehealthOnly(e.target.checked)}
                  className="rounded text-teal-600 focus:ring-teal-500 h-4 w-4"
                />
                <span className="flex items-center gap-1.5">
                  <Video className="w-3.5 h-3.5 text-teal-600" />
                  <span>Telehealth Video Consults</span>
                </span>
              </label>
            </div>
          </div>
        </div>
      </section>

      {/* DOCTORS GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="flex items-center justify-between mb-6 text-xs text-slate-500">
          <span>Showing {filteredDoctors.length} doctors</span>
          <span>Transparent upfront consultation fees</span>
        </div>

        {filteredDoctors.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-lg mx-auto">
            <Stethoscope className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-900">No physicians found matching criteria</h3>
            <p className="text-xs text-slate-500 mt-1 mb-4">
              Try adjusting your department filter or search terms.
            </p>
            <button
              onClick={resetFilters}
              className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDoctors.map((doctor) => (
              <DoctorCard
                key={doctor.id}
                doctor={doctor}
                onBookAppointment={(docId, deptId) => onOpenBooking(docId, deptId)}
                onViewDoctorProfile={(doc) => onViewDoctorProfile(doc)}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
