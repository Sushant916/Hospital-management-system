import React from 'react';
import { PageId } from '../types/hospital';
import { HOSPITAL_INFO, ACCREDITATIONS, HOSPITAL_MILESTONES } from '../data/hospitalData';
import { HOSPITAL_IMAGES } from '../assets/images';
import { 
  ShieldCheck, HeartPulse, Building2, Award, Users, 
  CheckCircle2, Clock, MapPin, Calendar, ArrowRight, Stethoscope
} from 'lucide-react';

interface AboutProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: () => void;
}

export const About: React.FC<AboutProps> = ({ onNavigate, onOpenBooking }) => {
  return (
    <div className="space-y-16 pb-16">
      {/* PAGE HEADER */}
      <section className="bg-slate-900 text-white py-16 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-2xl space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-teal-400">
              About WeCare Hospitals
            </span>
            <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-white">
              Compassionate Care Grounded in Clinical Excellence
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              Founded on the belief that cutting-edge tertiary medicine and sincere human warmth must never be separated, WeCare Hospitals has grown into one of the region's most trusted quaternary institutions.
            </p>
          </div>
        </div>
      </section>

      {/* CORE IDENTITY & MISSION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
              Our Guiding Philosophy
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display">
              A Quaternary Hospital Built Around the Patient Journey
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              WeCare Hospitals operates on a patient-first model. Rather than treating fragmented symptoms, our multi-disciplinary tumor boards, cardiovascular care councils, and stroke interventionists collaborate as a single coordinated care team around every admitted patient.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed">
              Our 450-bed campus integrates 12 modular robotic operation theaters, dual biplane cardiac cath labs, 48 intensive care beds, and outpatient consultation clinics engineered to eliminate unnecessary wait times.
            </p>

            <div className="pt-2 grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-2xs font-bold text-teal-700 uppercase tracking-wider block">Our Mission</span>
                <p className="text-xs text-slate-700 font-medium mt-1">
                  Deliver precision clinical outcomes with uncompromising empathy, safety, and price transparency.
                </p>
              </div>
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-2xs font-bold text-teal-700 uppercase tracking-wider block">Our Vision</span>
                <p className="text-xs text-slate-700 font-medium mt-1">
                  Pioneer next-generation minimally invasive therapeutics while making tertiary healthcare accessible to all.
                </p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="rounded-2xl overflow-hidden border border-slate-200 shadow-sm aspect-4/3 bg-slate-100">
              <img
                src={HOSPITAL_IMAGES.doctorConsultation}
                alt="Compassionate physician consultation at WeCare Hospitals"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-white p-5 rounded-xl border border-slate-200 shadow-lg max-w-xs hidden sm:block">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-teal-50 text-teal-700 flex items-center justify-center font-bold">
                  99%
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Patient Satisfaction</p>
                  <p className="text-2xs text-slate-500">Based on 14,000+ independent post-discharge reviews</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CORE VALUES */}
      <section className="bg-slate-100/60 border-y border-slate-200 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-10">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
              Institutional Values
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
              The Principles That Guide Every Decision
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200">
              <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-sm mb-4">
                01
              </div>
              <h3 className="text-base font-bold text-slate-900 font-display">Clinical Rigor</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Adherence to strict international clinical protocols, sterile infection barriers, and evidence-based diagnostic criteria.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200">
              <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-sm mb-4">
                02
              </div>
              <h3 className="text-base font-bold text-slate-900 font-display">Patient Dignity</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Every patient is treated with respect, deep listening, privacy, and full autonomy in medical decision-making.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200">
              <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-sm mb-4">
                03
              </div>
              <h3 className="text-base font-bold text-slate-900 font-display">Radical Transparency</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Clear treatment options, upfront surgical package estimates, and zero hidden billing surcharges.
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl border border-slate-200">
              <div className="w-9 h-9 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-sm mb-4">
                04
              </div>
              <h3 className="text-base font-bold text-slate-900 font-display">Rapid Innovation</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Continuously adopting robotic surgical arms, genomic targeted cancer therapies, and AI-assisted endoscopies.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ACCREDITATIONS & QUALITY SEALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="border border-slate-200 rounded-2xl p-6 sm:p-10 bg-white">
          <div className="max-w-xl mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
              International Benchmarks
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
              Accreditations & Certifications
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Our clinical outcomes, sterility metrics, and laboratory accuracies are independently evaluated by global regulatory bodies.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {ACCREDITATIONS.map((acc, i) => (
              <div key={i} className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-teal-700 font-semibold text-xs mb-2">
                    <ShieldCheck className="w-4 h-4" />
                    <span>{acc.issuer}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900 font-display">{acc.title}</h4>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed">{acc.description}</p>
                </div>
                <div className="mt-4 pt-2 border-t border-slate-200 text-2xs text-slate-400 font-medium">
                  Status: {acc.year}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HISTORICAL TIMELINE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="max-w-xl mb-8">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
            Our Growth Story
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
            Milestones in Healthcare Leadership
          </h2>
        </div>

        <div className="border-l-2 border-slate-200 pl-6 sm:pl-8 space-y-8 ml-2 sm:ml-4">
          {HOSPITAL_MILESTONES.map((mile, i) => (
            <div key={i} className="relative group">
              {/* Timeline marker */}
              <div className="absolute -left-[31px] sm:-left-[39px] top-1 w-4 h-4 rounded-full bg-white border-2 border-teal-600 group-hover:bg-teal-600 transition-colors" />
              <div className="flex items-baseline gap-3">
                <span className="text-base font-extrabold text-teal-700 font-mono">{mile.year}</span>
                <h3 className="text-base font-bold text-slate-900 font-display">{mile.title}</h3>
              </div>
              <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
                {mile.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA STRIP */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="bg-slate-900 text-white rounded-2xl p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-lg">
            <h3 className="text-xl sm:text-2xl font-bold font-display text-white">
              Experience the WeCare Standard of Healthcare
            </h3>
            <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
              Whether you require routine preventative screening or complex surgical evaluation, our team is ready to support you.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('doctors')}
              className="px-5 py-2.5 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-lg transition-colors border border-white/20"
            >
              Browse Medical Staff
            </button>
            <button
              onClick={onOpenBooking}
              className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-xs"
            >
              Book an Appointment
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
