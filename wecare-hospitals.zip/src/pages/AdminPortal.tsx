import React, { useState, useMemo } from 'react';
import { Appointment, Doctor, Department, PageId } from '../types/hospital';
import { DEPARTMENTS, DOCTORS, HOSPITAL_INFO } from '../data/hospitalData';
import { AdminBookingModal } from '../components/AdminBookingModal';
import { AdminEditBookingModal } from '../components/AdminEditBookingModal';
import { useAuth } from '../context/AuthContext';
import { 
  ShieldCheck, Lock, Mail, Search, Filter, Plus, Download, 
  ExternalLink, LogOut, CheckCircle2, Clock, AlertCircle, 
  Building2, Stethoscope, RefreshCw, Printer, Trash2, ArrowUpDown, ChevronRight, UserCheck
} from 'lucide-react';

interface AdminPortalProps {
  appointments: Appointment[];
  onNavigate: (page: PageId) => void;
  onSaveAppointment: (appointment: Appointment) => void;
  onUpdateAppointment: (updated: Appointment) => void;
  onDeleteAppointment: (id: string) => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  appointments,
  onNavigate,
  onSaveAppointment,
  onUpdateAppointment,
  onDeleteAppointment
}) => {
  const { currentUser, signInWithEmail, signUpWithEmail, logout } = useAuth();

  // Admin authentication state
  // Check if current user is the admin or if local admin session is active
  const ADMIN_EMAIL = 'sushantanundruka123@gmail.com';
  const ADMIN_PASSWORD = 'Sushant@123';

  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    try {
      const saved = sessionStorage.getItem('wecare_admin_logged_in');
      return saved === 'true' || currentUser?.email === ADMIN_EMAIL;
    } catch {
      return false;
    }
  });

  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  // Table filters & search
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [deptFilter, setDeptFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'upcoming'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'date-asc' | 'patient'>('newest');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingBooking, setEditingBooking] = useState<Appointment | null>(null);

  // Handle Admin Login
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);

    const emailTrimmed = loginEmail.trim().toLowerCase();

    // Check against authorized admin credentials
    if (emailTrimmed !== ADMIN_EMAIL.toLowerCase() || loginPassword !== ADMIN_PASSWORD) {
      setLoginError('Invalid administrator credentials. Please check your email and password.');
      setLoginLoading(false);
      return;
    }

    try {
      // Also authenticate with Firebase Auth
      try {
        await signInWithEmail(ADMIN_EMAIL, ADMIN_PASSWORD);
      } catch (authErr: any) {
        // If not yet registered in Firebase Auth, automatically create admin account
        if (authErr?.message?.includes('user-not-found') || authErr?.message?.includes('invalid-credential')) {
          try {
            await signUpWithEmail(ADMIN_EMAIL, ADMIN_PASSWORD, 'Hospital Administrator');
          } catch (createErr) {
            console.warn('Firebase admin account creation notice:', createErr);
          }
        }
      }

      sessionStorage.setItem('wecare_admin_logged_in', 'true');
      setIsAdminLoggedIn(true);
      setLoginLoading(false);
    } catch (err: any) {
      // Even if Firebase auth has network latency, authorized local admin session succeeds
      sessionStorage.setItem('wecare_admin_logged_in', 'true');
      setIsAdminLoggedIn(true);
      setLoginLoading(false);
    }
  };

  const handleAdminLogout = () => {
    sessionStorage.removeItem('wecare_admin_logged_in');
    setIsAdminLoggedIn(false);
    if (currentUser?.email === ADMIN_EMAIL) {
      logout();
    }
  };

  const handleQuickFill = () => {
    setLoginEmail(ADMIN_EMAIL);
    setLoginPassword(ADMIN_PASSWORD);
    setLoginError(null);
  };

  // Filtered appointments
  const filteredBookings = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];

    return appointments.filter(b => {
      // Status filter
      if (statusFilter !== 'all' && b.status !== statusFilter) return false;

      // Department filter
      if (deptFilter !== 'all' && b.departmentId !== deptFilter) return false;

      // Date filter
      if (dateFilter === 'today' && b.date !== todayStr) return false;
      if (dateFilter === 'upcoming' && b.date < todayStr) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchRef = b.referenceCode.toLowerCase().includes(q);
        const matchPatient = b.patientName.toLowerCase().includes(q);
        const matchPhone = b.patientPhone.toLowerCase().includes(q);
        const matchEmail = b.patientEmail.toLowerCase().includes(q);
        const matchDoc = b.doctorName.toLowerCase().includes(q);
        const matchDept = b.departmentName.toLowerCase().includes(q);
        return matchRef || matchPatient || matchPhone || matchEmail || matchDoc || matchDept;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sortBy === 'date-asc') return a.date.localeCompare(b.date);
      if (sortBy === 'patient') return a.patientName.localeCompare(b.patientName);
      return 0;
    });
  }, [appointments, statusFilter, deptFilter, dateFilter, searchQuery, sortBy]);

  // Executive Operational Metrics
  const metrics = useMemo(() => {
    const todayStr = new Date().toISOString().split('T')[0];
    const total = appointments.length;
    const confirmed = appointments.filter(a => a.status === 'confirmed').length;
    const inConsultation = appointments.filter(a => a.status === 'in-consultation').length;
    const completed = appointments.filter(a => a.status === 'completed').length;
    const cancelled = appointments.filter(a => a.status === 'cancelled').length;
    const todayCount = appointments.filter(a => a.date === todayStr && a.status !== 'cancelled').length;
    const totalRevenue = appointments
      .filter(a => a.status !== 'cancelled')
      .reduce((sum, a) => sum + (Number(a.consultationFee) || 0), 0);

    return { total, confirmed, inConsultation, completed, cancelled, todayCount, totalRevenue };
  }, [appointments]);

  // Export Bookings as CSV
  const handleExportCSV = () => {
    const headers = ['Reference', 'Patient Name', 'Phone', 'Email', 'Doctor', 'Department', 'Date', 'Time Slot', 'Mode', 'Room', 'Fee ($)', 'Status', 'Booked At'];
    const rows = filteredBookings.map(b => [
      b.referenceCode,
      `"${b.patientName}"`,
      `"${b.patientPhone}"`,
      `"${b.patientEmail}"`,
      `"${b.doctorName}"`,
      `"${b.departmentName}"`,
      b.date,
      b.timeSlot,
      b.consultationType,
      `"${b.roomNumber || ''}"`,
      b.consultationFee,
      b.status,
      b.createdAt
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `wecare-hospital-bookings-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Quick Status change inline
  const handleQuickStatusChange = (booking: Appointment, newStatus: Appointment['status']) => {
    onUpdateAppointment({ ...booking, status: newStatus });
  };

  // -------------------------------------------------------------
  // VIEW 1: ADMIN LOGIN SCREEN (If not authenticated as admin)
  // -------------------------------------------------------------
  if (!isAdminLoggedIn) {
    return (
      <div className="min-h-[85vh] flex items-center justify-center p-4 bg-slate-900">
        <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
          {/* Header */}
          <div className="p-6 bg-slate-950 text-white text-center border-b border-slate-800">
            <div className="w-12 h-12 bg-teal-600 rounded-xl flex items-center justify-center mx-auto text-white shadow-lg shadow-teal-900/40 mb-3">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-extrabold font-display tracking-tight text-white">
              WeCare Administration Desk
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Secure Operations, Triage & Executive Booking Gateway
            </p>
          </div>

          {/* Login Form */}
          <div className="p-6 space-y-4">
            {loginError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
                <span>{loginError}</span>
              </div>
            )}

            <form onSubmit={handleAdminLogin} className="space-y-3.5">
              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Administrator Email
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    placeholder="admin@wecarehospitals.org"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Security Passcode
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loginLoading}
                className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg shadow-sm shadow-teal-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {loginLoading ? (
                  <span>Verifying Credentials...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Authorize Admin Session</span>
                  </>
                )}
              </button>
            </form>

            {/* Quick-fill Button for Convenience */}
            <div className="pt-2 border-t border-slate-100 text-center">
              <button
                type="button"
                onClick={handleQuickFill}
                className="text-xs text-teal-700 hover:text-teal-900 font-semibold underline cursor-pointer"
              >
                Auto-Fill Authorized Admin Credentials
              </button>
              <p className="text-2xs text-slate-400 mt-1 font-mono">
                {ADMIN_EMAIL}
              </p>
            </div>
          </div>

          <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-2xs text-slate-500">
            <button
              onClick={() => onNavigate('home')}
              className="text-teal-700 hover:underline font-semibold"
            >
              ← Return to Public Hospital Site
            </button>
            <span>SSL Encrypted</span>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // VIEW 2: AUTHENTICATED ADMIN OPERATIONS DASHBOARD
  // -------------------------------------------------------------
  return (
    <div className="bg-slate-100 min-h-screen pb-16">
      {/* Top Admin Action Header */}
      <div className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white">
              <Building2 className="w-4.5 h-4.5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold font-display text-white">
                  WeCare Hospital Executive Operations
                </h1>
                <span className="text-2xs px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 font-mono border border-teal-500/30">
                  Admin Console
                </span>
              </div>
              <p className="text-2xs text-slate-400">
                Logged in: <strong className="text-slate-200">{ADMIN_EMAIL}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => onNavigate('home')}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold rounded-lg transition-colors border border-white/20 flex items-center gap-1.5 cursor-pointer"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Public Site</span>
            </button>
            <button
              onClick={handleExportCSV}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>+ Add Booking</span>
            </button>
            <button
              onClick={handleAdminLogout}
              className="p-1.5 text-slate-400 hover:text-rose-400 rounded-lg transition-colors"
              title="Sign Out Admin"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Workspace */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 space-y-6">
        
        {/* Metric Cards Row (Tabular Figures) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
              Total Hospital Bookings
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display tabular-nums mt-1">
              {metrics.total}
            </div>
            <div className="flex items-center gap-2 text-2xs text-slate-500 mt-1">
              <span className="text-teal-700 font-semibold">{metrics.confirmed} Confirmed</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-700 font-semibold">{metrics.completed} Done</span>
            </div>
          </div>

          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
              Today's Scheduled Visits
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold text-teal-700 font-display tabular-nums mt-1">
              {metrics.todayCount}
            </div>
            <p className="text-2xs text-slate-500 mt-1">
              {metrics.inConsultation} patient(s) in consultation
            </p>
          </div>

          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
              Consultation Incurred Fees
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display tabular-nums mt-1">
              ${metrics.totalRevenue.toLocaleString()}
            </div>
            <p className="text-2xs text-slate-500 mt-1">
              Across active outpatient clinics
            </p>
          </div>

          <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
            <span className="text-2xs font-bold uppercase tracking-wider text-slate-400 block">
              Clinical Specializations
            </span>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display tabular-nums mt-1">
              {DEPARTMENTS.length}
            </div>
            <p className="text-2xs text-slate-500 mt-1">
              {DOCTORS.length} Board-Certified Specialists
            </p>
          </div>
        </div>

        {/* Filter and Search Bar */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs space-y-3">
          <div className="flex flex-col md:flex-row items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by Patient Name, Phone, Email, Doctor, or Reference Code (WCH-...)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
              />
            </div>

            {/* Department Dropdown */}
            <div className="w-full md:w-56 shrink-0">
              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
              >
                <option value="all">All Clinical Departments</option>
                {DEPARTMENTS.map(d => (
                  <option key={d.id} value={d.id}>{d.name.split('&')[0]}</option>
                ))}
              </select>
            </div>

            {/* Date Range Dropdown */}
            <div className="w-full md:w-36 shrink-0">
              <select
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
              >
                <option value="all">All Dates</option>
                <option value="today">Today Only</option>
                <option value="upcoming">Upcoming Only</option>
              </select>
            </div>

            {/* Sort Order */}
            <div className="w-full md:w-36 shrink-0">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
              >
                <option value="newest">Booked Newest</option>
                <option value="date-asc">Earliest Slot</option>
                <option value="patient">Patient Name</option>
              </select>
            </div>
          </div>

          {/* Status Tabs */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2 text-xs">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
              {(['all', 'confirmed', 'in-consultation', 'completed', 'rescheduled', 'cancelled'] as const).map((st) => (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-3 py-1 rounded-md capitalize font-semibold transition-all cursor-pointer whitespace-nowrap ${
                    statusFilter === st
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {st.replace('-', ' ')}
                  <span className="ml-1.5 opacity-70 font-mono text-2xs">
                    ({st === 'all' ? appointments.length : appointments.filter(a => a.status === st).length})
                  </span>
                </button>
              ))}
            </div>

            {(searchQuery || statusFilter !== 'all' || deptFilter !== 'all' || dateFilter !== 'all') && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setStatusFilter('all');
                  setDeptFilter('all');
                  setDateFilter('all');
                }}
                className="text-2xs text-rose-600 hover:underline font-semibold"
              >
                Clear Filters
              </button>
            )}
          </div>
        </div>

        {/* Data Table */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50/60">
            <div className="text-xs text-slate-600 font-semibold">
              Showing <span className="font-bold text-slate-900 tabular-nums">{filteredBookings.length}</span> of {appointments.length} Hospital Bookings
            </div>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="text-xs font-bold text-teal-700 hover:text-teal-900 flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create New Booking</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100/70 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-2xs">
                  <th className="py-3 px-4">Ref Code</th>
                  <th className="py-3 px-4">Patient Profile</th>
                  <th className="py-3 px-4">Attending Doctor</th>
                  <th className="py-3 px-4">Schedule</th>
                  <th className="py-3 px-4">Facility & Mode</th>
                  <th className="py-3 px-4 text-right">Fee</th>
                  <th className="py-3 px-4">Status & Action</th>
                  <th className="py-3 px-4 text-right">Manage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredBookings.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-slate-400">
                      <Stethoscope className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                      <p className="font-bold text-slate-700">No bookings found matching current filters</p>
                      <button
                        onClick={() => setIsAddModalOpen(true)}
                        className="mt-3 px-3.5 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold"
                      >
                        + Create Hospital Booking
                      </button>
                    </td>
                  </tr>
                ) : (
                  filteredBookings.map((b) => {
                    const statusColors = {
                      'confirmed': 'bg-teal-50 text-teal-800 border-teal-200',
                      'in-consultation': 'bg-blue-50 text-blue-800 border-blue-200',
                      'completed': 'bg-emerald-50 text-emerald-800 border-emerald-200',
                      'rescheduled': 'bg-amber-50 text-amber-800 border-amber-200',
                      'cancelled': 'bg-rose-50 text-rose-800 border-rose-200'
                    };

                    return (
                      <tr key={b.id} className="hover:bg-slate-50/80 transition-colors">
                        {/* Ref Code */}
                        <td className="py-3 px-4 whitespace-nowrap">
                          <span className="font-mono text-xs font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                            {b.referenceCode}
                          </span>
                        </td>

                        {/* Patient */}
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900 leading-tight">{b.patientName}</div>
                          <div className="text-2xs text-slate-500">{b.patientPhone}</div>
                          <div className="text-2xs text-slate-400 flex items-center gap-1.5 mt-0.5">
                            <span>{b.patientGender}, Age {b.patientAge}</span>
                            {b.isExistingPatient && (
                              <span className="text-teal-700 font-semibold">· Prior Rec</span>
                            )}
                          </div>
                        </td>

                        {/* Doctor */}
                        <td className="py-3 px-4">
                          <div className="font-bold text-slate-900">{b.doctorName}</div>
                          <div className="text-2xs text-slate-500">{b.departmentName.split('&')[0]}</div>
                        </td>

                        {/* Date & Time */}
                        <td className="py-3 px-4 whitespace-nowrap">
                          <div className="font-bold text-slate-800 tabular-nums">{b.date}</div>
                          <div className="text-teal-700 font-semibold">{b.timeSlot}</div>
                        </td>

                        {/* Mode & Room */}
                        <td className="py-3 px-4">
                          <div className="capitalize font-semibold text-slate-800">{b.consultationType}</div>
                          <div className="text-2xs text-slate-500 truncate max-w-[140px]">
                            {b.roomNumber || 'Clinic Suite'}
                          </div>
                        </td>

                        {/* Fee */}
                        <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 tabular-nums">
                          ${b.consultationFee}
                        </td>

                        {/* Status (Interactive Quick Status Selector) */}
                        <td className="py-3 px-4 whitespace-nowrap">
                          <select
                            value={b.status}
                            onChange={(e) => handleQuickStatusChange(b, e.target.value as any)}
                            className={`px-2 py-1 rounded text-2xs font-bold border capitalize cursor-pointer focus:outline-none ${statusColors[b.status] || 'bg-slate-100'}`}
                          >
                            <option value="confirmed">Confirmed</option>
                            <option value="in-consultation">In Consultation</option>
                            <option value="completed">Completed</option>
                            <option value="rescheduled">Rescheduled</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </td>

                        {/* Actions */}
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <button
                            type="button"
                            onClick={() => setEditingBooking(b)}
                            className="px-2.5 py-1 text-xs font-semibold text-teal-700 hover:text-teal-900 hover:bg-teal-50 rounded-lg transition-colors cursor-pointer"
                          >
                            Manage
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Admin Add Booking Modal */}
      <AdminBookingModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSaveBooking={(newBooking) => {
          onSaveAppointment(newBooking);
        }}
      />

      {/* Admin Edit / Manage Booking Modal */}
      <AdminEditBookingModal
        booking={editingBooking}
        isOpen={!!editingBooking}
        onClose={() => setEditingBooking(null)}
        onUpdateBooking={(updated) => {
          onUpdateAppointment(updated);
        }}
        onDeleteBooking={(id) => {
          onDeleteAppointment(id);
        }}
      />
    </div>
  );
};
