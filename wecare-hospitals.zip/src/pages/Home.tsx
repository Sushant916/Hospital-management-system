import React, { useState } from 'react';
import { PageId, Doctor } from '../types/hospital';
import { HOSPITAL_INFO, DEPARTMENTS, DOCTORS, CARE_STORIES } from '../data/hospitalData';
import { HOSPITAL_IMAGES } from '../assets/images';
import { DoctorCard } from '../components/DoctorCard';
import { 
  ShieldAlert, Calendar, ArrowRight, Stethoscope, Award, 
  CheckCircle2, Clock, Phone, HeartPulse, Sparkles, Building2,
  Users, Activity, ChevronRight
} from 'lucide-react';

interface HomeProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: (doctorId?: string, departmentId?: string) => void;
  onViewDoctorProfile: (doctor: Doctor) => void;
}

export const Home: React.FC<HomeProps> = ({
  onNavigate,
  onOpenBooking,
  onViewDoctorProfile
}) => {
  const [quickDept, setQuickDept] = useState<string>(DEPARTMENTS[0].id);
  const [quickDoc, setQuickDoc] = useState<string>('');

  const quickDeptDoctors = DOCTORS.filter(d => d.departmentId === quickDept);

  const handleQuickBook = (e: React.FormEvent) => {
    e.preventDefault();
    onOpenBooking(quickDoc || undefined, quickDept);
  };

  return (
    <div className="space-y-16 pb-16">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden bg-slate-900 text-white">
        {/* Background Image with Measured Contrast Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src={HOSPITAL_IMAGES.heroExterior}
            alt="WeCare Hospitals Modern Medical Campus"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center opacity-40 mix-blend-luminosity scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-slate-900/60" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-8 py-16 sm:py-24">
          <div className="max-w-2xl space-y-6">
            <div className="inline-flex items-center gap-2 text-teal-300 text-xs font-semibold tracking-wider uppercase">
              <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse" />
              <span>JCI Gold Seal Accredited Multispecialty Institution</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight font-display text-balance">
              Advanced Medicine, <br />
              <span className="text-teal-400">Compassionate Care.</span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal">
              At WeCare Hospitals, world-class medical specialists, robotic surgical technology, and evidence-based clinical protocols unite to restore health and dignity.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => onOpenBooking()}
                className="px-6 py-3.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl shadow-lg shadow-teal-600/30 transition-all flex items-center gap-2 cursor-pointer"
              >
                <Calendar className="w-4.5 h-4.5" />
                <span>Book Doctor Appointment</span>
              </button>
              <button
                onClick={() => onNavigate('doctors')}
                className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white text-sm font-semibold rounded-xl backdrop-blur-xs transition-colors flex items-center gap-2 cursor-pointer border border-white/20"
              >
                <span>Explore 140+ Doctors</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Quick Appointment Finder Floating Card */}
          <div className="mt-12 bg-white text-slate-900 rounded-2xl p-5 sm:p-6 shadow-xl border border-slate-200/80 max-w-4xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <Stethoscope className="w-4 h-4 text-teal-600" />
                Fast Clinic Appointment Finder
              </span>
              <span className="text-xs text-teal-700 font-semibold">Zero Waiting Time Guarantee</span>
            </div>

            <form onSubmit={handleQuickBook} className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-500 mb-1">
                  1. Clinical Department
                </label>
                <select
                  value={quickDept}
                  onChange={(e) => {
                    setQuickDept(e.target.value);
                    setQuickDoc('');
                  }}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:border-teal-600 focus:bg-white"
                >
                  {DEPARTMENTS.map(d => (
                    <option key={d.id} value={d.id}>{d.name.split('&')[0]}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-500 mb-1">
                  2. Choose Specialist
                </label>
                <select
                  value={quickDoc}
                  onChange={(e) => setQuickDoc(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:border-teal-600 focus:bg-white"
                >
                  <option value="">Any Available Specialist</option>
                  {quickDeptDoctors.map(doc => (
                    <option key={doc.id} value={doc.id}>{doc.name} (${doc.consultationFee})</option>
                  ))}
                </select>
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Check Available Slots</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* QUANTITATIVE CLINICAL IMPACT METRICS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          <div className="p-5 rounded-xl bg-white border border-slate-200">
            <span className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tabular-nums">
              {HOSPITAL_INFO.metrics.beds}
            </span>
            <p className="text-xs text-slate-500 font-medium mt-1">Multi-Specialty Inpatient Beds</p>
            <p className="text-2xs text-slate-400 mt-1">Including 48 Intensive Care Beds</p>
          </div>

          <div className="p-5 rounded-xl bg-white border border-slate-200">
            <span className="text-3xl sm:text-4xl font-extrabold text-teal-700 font-display tabular-nums">
              {HOSPITAL_INFO.metrics.doctors}
            </span>
            <p className="text-xs text-slate-500 font-medium mt-1">Board-Certified Specialists</p>
            <p className="text-2xs text-slate-400 mt-1">Across 8 Centres of Excellence</p>
          </div>

          <div className="p-5 rounded-xl bg-white border border-slate-200">
            <span className="text-3xl sm:text-4xl font-extrabold text-slate-900 font-display tabular-nums">
              {HOSPITAL_INFO.metrics.surgeriesCompleted}
            </span>
            <p className="text-xs text-slate-500 font-medium mt-1">Surgeries Completed</p>
            <p className="text-2xs text-slate-400 mt-1">Robotic & minimally invasive precision</p>
          </div>

          <div className="p-5 rounded-xl bg-white border border-slate-200">
            <span className="text-3xl sm:text-4xl font-extrabold text-teal-700 font-display tabular-nums">
              {HOSPITAL_INFO.metrics.satisfactionRate}
            </span>
            <p className="text-xs text-slate-500 font-medium mt-1">Patient Care Satisfaction</p>
            <p className="text-2xs text-slate-400 mt-1">Independently audited patient outcomes</p>
          </div>
        </div>
      </section>

      {/* CLINICAL DEPARTMENTS PREVIEW */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
              Centers of Excellence
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
              Specialized Clinical Departments
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-xl">
              Each department is staffed by dedicated senior consultants, specialized fellows, and state-of-the-art diagnostic labs.
            </p>
          </div>

          <button
            onClick={() => onNavigate('departments')}
            className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1 group"
          >
            <span>View All 8 Departments</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* Bento grid of departments */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {DEPARTMENTS.slice(0, 4).map((dept) => {
            const docCount = DOCTORS.filter(d => d.departmentId === dept.id).length;
            return (
              <div
                key={dept.id}
                className="bg-white rounded-xl border border-slate-200 p-5 flex flex-col justify-between hover:border-teal-500/50 hover:shadow-sm transition-all"
              >
                <div>
                  <div className="flex items-center justify-between text-2xs text-slate-400 mb-2">
                    <span>{dept.floor}</span>
                    <span className="text-teal-700 font-semibold">{docCount} Specialists</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 font-display">
                    {dept.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-2 line-clamp-3 leading-relaxed">
                    {dept.shortDescription}
                  </p>

                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <p className="text-2xs font-semibold uppercase text-slate-400 tracking-wider mb-1">
                      Key Interventions
                    </p>
                    <div className="text-xs text-slate-600 line-clamp-2">
                      {dept.treatments.slice(0, 2).join(' · ')}
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => onNavigate('departments')}
                    className="text-xs font-semibold text-slate-600 hover:text-slate-900"
                  >
                    Details
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenBooking(undefined, dept.id)}
                    className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1 cursor-pointer"
                  >
                    <span>Book In Dept</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ADVANCED INFRASTRUCTURE & FACILITIES */}
      <section className="bg-slate-100/70 border-y border-slate-200 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
              Modern Clinical Infrastructure
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
              Precision Technology Designed Around Healing
            </h2>
            <p className="text-sm text-slate-600 mt-2">
              From modular robotic operating suites to serene private inpatient recovery rooms, our facilities are engineered for clinical safety and patient peace.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            {/* Facility Card 1 */}
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="aspect-16/9 bg-slate-200 overflow-hidden relative">
                <img
                  src={HOSPITAL_IMAGES.operatingTheater}
                  alt="State of the art robotic operating theater at WeCare Hospitals"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
                  12 Ultra-Clean Surgical Suites
                </div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Robotic Surgical Theaters & Cath Labs
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Equipped with HEPA laminar airflows, da Vinci® Xi robotic consoles, and biplane fluoroscopy to reduce surgical trauma and expedite recovery.
                </p>
                <div className="mt-4 flex items-center gap-3 text-xs text-slate-500">
                  <span>99.98% Sterile Air Purity</span>
                  <span aria-hidden="true">·</span>
                  <span>Zero Infection Protocol</span>
                </div>
              </div>
            </div>

            {/* Facility Card 2 */}
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <div className="aspect-16/9 bg-slate-200 overflow-hidden relative">
                <img
                  src={HOSPITAL_IMAGES.hospitalFacilities}
                  alt="Serene inpatient patient recovery suites at WeCare"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
                  Holistic Patient Environment
                </div>
                <h3 className="text-lg font-bold text-slate-900 font-display">
                  Private Inpatient Recovery Suites
                </h3>
                <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                  Natural sunlight, acoustic soundproofing, ergonomic family sleep lounges, and 24/7 direct nurse tele-monitoring in every patient room.
                </p>
                <div className="mt-4 flex items-center gap-3 text-xs text-slate-500">
                  <span>1:1 Acute Care Nursing</span>
                  <span aria-hidden="true">·</span>
                  <span>Healing Garden Views</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURED DOCTORS SPOTLIGHT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
              Our Medical Faculty
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
              Meet Our Chief Physicians & Specialists
            </h2>
            <p className="text-sm text-slate-500 mt-1 max-w-xl">
              Trained at the world’s leading teaching hospitals including Harvard, Mayo Clinic, Johns Hopkins, and Stanford.
            </p>
          </div>

          <button
            onClick={() => onNavigate('doctors')}
            className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1 group"
          >
            <span>Browse All {DOCTORS.length} Doctors</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {DOCTORS.slice(0, 3).map((doctor) => (
            <DoctorCard
              key={doctor.id}
              doctor={doctor}
              onBookAppointment={(docId, deptId) => onOpenBooking(docId, deptId)}
              onViewDoctorProfile={(doc) => onViewDoctorProfile(doc)}
            />
          ))}
        </div>
      </section>

      {/* PATIENT CARE STORIES & REAL OUTCOMES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="border border-slate-200 rounded-2xl p-6 sm:p-10 bg-white">
          <div className="max-w-xl mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">
              Audited Clinical Proof
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-display mt-1">
              Real Patient Outcomes & Recovery Stories
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {CARE_STORIES.map((story) => (
              <div key={story.id} className="p-5 rounded-xl bg-slate-50 border border-slate-100 flex flex-col justify-between">
                <div>
                  <div className="text-xs text-teal-700 font-bold uppercase tracking-wider">
                    {story.department}
                  </div>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    Condition: {story.condition}
                  </p>

                  <p className="text-xs text-slate-700 italic mt-3 leading-relaxed">
                    "{story.quote}"
                  </p>

                  <div className="mt-3 pt-3 border-t border-slate-200/80">
                    <p className="text-2xs uppercase tracking-wider text-slate-400 font-semibold">
                      Documented Clinical Outcome
                    </p>
                    <p className="text-xs text-slate-900 font-medium mt-0.5">
                      {story.outcome}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
                  <span className="font-bold text-slate-800">{story.patientName}, {story.patientAge} yrs</span>
                  <span>{story.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* EMERGENCY TRIAGE STRIP */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="bg-gradient-to-r from-rose-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6 shadow-md">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-rose-600/30 border border-rose-500/40 text-rose-400 flex items-center justify-center shrink-0">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold font-display text-white">
                24/7 Level-1 Emergency & Trauma Care
              </h3>
              <p className="text-xs text-rose-200 mt-1">
                Zero gate delays for acute cardiac arrest, polytrauma, stroke thrombolysis, and pediatric distress.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <a
              href={`tel:${HOSPITAL_INFO.emergencyPhone.replace(/[^0-9+]/g, '')}`}
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 shadow-xs"
            >
              <Phone className="w-4 h-4" />
              <span>Call Ambulance: {HOSPITAL_INFO.emergencyPhone}</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
