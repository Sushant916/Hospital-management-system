import React, { useState, useMemo } from 'react';
import { Department, Doctor, PageId } from '../types/hospital';
import { DEPARTMENTS, DOCTORS, HOSPITAL_INFO } from '../data/hospitalData';
import { 
  Search, ShieldAlert, Users, Building2, Stethoscope, 
  ArrowRight, CheckCircle2, ChevronRight, Phone, Cpu 
} from 'lucide-react';

interface DepartmentsProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: (doctorId?: string, departmentId?: string) => void;
  onSelectDepartment: (department: Department) => void;
  onViewDoctorProfile: (doctor: Doctor) => void;
}

export const Departments: React.FC<DepartmentsProps> = ({
  onNavigate,
  onOpenBooking,
  onSelectDepartment,
  onViewDoctorProfile
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterEmergencyOnly, setFilterEmergencyOnly] = useState(false);

  // Filtered departments based on search query (name, conditions, treatments)
  const filteredDepartments = useMemo(() => {
    return DEPARTMENTS.filter(dept => {
      if (filterEmergencyOnly && !dept.emergencyAvailable) return false;

      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase();
      const matchName = dept.name.toLowerCase().includes(q);
      const matchDesc = dept.shortDescription.toLowerCase().includes(q) || dept.fullDescription.toLowerCase().includes(q);
      const matchConditions = dept.conditions.some(c => c.toLowerCase().includes(q));
      const matchTreatments = dept.treatments.some(t => t.toLowerCase().includes(q));

      return matchName || matchDesc || matchConditions || matchTreatments;
    });
  }, [searchQuery, filterEmergencyOnly]);

  return (
    <div className="space-y-12 pb-16">
      {/* HEADER */}
      <section className="bg-slate-900 text-white py-14 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-2xl space-y-4">
            <span className="text-xs font-semibold uppercase tracking-wider text-teal-400">
              Specialized Clinical Care
            </span>
            <h1 className="text-3xl sm:text-5xl font-extrabold font-display tracking-tight text-white">
              Centres of Clinical Excellence
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
              WeCare Hospitals features eight tertiary and quaternary specialty divisions, each equipped with dedicated outpatient suites, surgical theaters, and specialized inpatient intensive care units.
            </p>
          </div>

          {/* Search & Filter Bar */}
          <div className="mt-8 bg-white/10 backdrop-blur-md p-3.5 rounded-xl border border-white/20 flex flex-col sm:flex-row items-center gap-3">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-300 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search departments, conditions (e.g. stroke, arthritis), or treatments..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white/90 text-slate-900 placeholder:text-slate-500 rounded-lg text-xs font-medium focus:bg-white focus:outline-teal-500"
              />
            </div>

            <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
              <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={filterEmergencyOnly}
                  onChange={(e) => setFilterEmergencyOnly(e.target.checked)}
                  className="rounded text-teal-600 focus:ring-teal-500 h-4 w-4 border-slate-400"
                />
                <span>24/7 Emergency Available Only</span>
              </label>

              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="text-xs text-teal-300 hover:text-white underline cursor-pointer"
                >
                  Clear search
                </button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* DEPARTMENT CARDS GRID */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="flex items-center justify-between mb-6 text-xs text-slate-500">
          <span>Showing {filteredDepartments.length} of {DEPARTMENTS.length} clinical divisions</span>
          <span>Each department includes multiple dedicated senior specialists</span>
        </div>

        {filteredDepartments.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-lg mx-auto">
            <Building2 className="w-12 h-12 text-slate-400 mx-auto mb-3" />
            <h3 className="text-base font-bold text-slate-900">No departments match your query</h3>
            <p className="text-xs text-slate-500 mt-1 mb-4">
              Try searching for a different condition, or view our comprehensive doctor directory.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setFilterEmergencyOnly(false);
              }}
              className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {filteredDepartments.map((dept) => {
              const deptDoctors = DOCTORS.filter(d => d.departmentId === dept.id);

              return (
                <div
                  key={dept.id}
                  className="bg-white rounded-2xl border border-slate-200 hover:border-teal-500/60 transition-all p-6 sm:p-7 flex flex-col justify-between shadow-xs"
                >
                  <div>
                    {/* Header Strip */}
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div>
                        <div className="flex items-center gap-2 text-2xs text-slate-400 font-medium mb-1">
                          <span>{dept.floor}</span>
                          <span aria-hidden="true">·</span>
                          <span>{dept.bedCount} Inpatient Beds</span>
                        </div>
                        <h2 className="text-xl font-bold text-slate-900 font-display">
                          {dept.name}
                        </h2>
                        <p className="text-xs text-teal-700 font-medium mt-0.5">
                          {dept.tagline}
                        </p>
                      </div>

                      {dept.emergencyAvailable ? (
                        <span className="shrink-0 px-2 py-0.5 rounded text-2xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          24/7 Triage
                        </span>
                      ) : (
                        <span className="shrink-0 px-2 py-0.5 rounded text-2xs font-medium bg-slate-100 text-slate-600">
                          Scheduled Clinic
                        </span>
                      )}
                    </div>

                    {/* Short Description */}
                    <p className="text-xs text-slate-600 leading-relaxed mt-2">
                      {dept.shortDescription}
                    </p>

                    {/* Doctors in this department */}
                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-2xs font-bold uppercase tracking-wider text-slate-400">
                          Specialists ({deptDoctors.length})
                        </span>
                        <span className="text-2xs text-slate-500">
                          Head: <strong className="text-slate-800">{dept.headDoctorName}</strong>
                        </span>
                      </div>

                      <div className="space-y-1.5">
                        {deptDoctors.map((doc) => (
                          <div
                            key={doc.id}
                            onClick={() => onViewDoctorProfile(doc)}
                            className="p-2 rounded-lg bg-slate-50 hover:bg-teal-50/50 border border-slate-100 flex items-center justify-between text-xs cursor-pointer transition-colors"
                          >
                            <div className="flex items-center gap-2">
                              <div className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 font-bold text-2xs flex items-center justify-center">
                                {doc.name.split(' ').slice(1).map(n => n[0]).join('')}
                              </div>
                              <span className="font-semibold text-slate-800 hover:text-teal-700">{doc.name}</span>
                              <span className="text-slate-400 hidden sm:inline">· {doc.title.split('&')[0]}</span>
                            </div>
                            <span className="text-slate-600 font-medium">${doc.consultationFee}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Key Interventions */}
                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <p className="text-2xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                        Specialized Procedures
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {dept.treatments.slice(0, 3).map((treatment, i) => (
                          <span
                            key={i}
                            className="text-2xs px-2 py-0.5 bg-slate-100 text-slate-700 rounded font-medium"
                          >
                            {treatment}
                          </span>
                        ))}
                        {dept.treatments.length > 3 && (
                          <span className="text-2xs px-1.5 py-0.5 text-slate-400">
                            +{dept.treatments.length - 3} more
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-6 pt-4 border-t border-slate-100 grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => onSelectDepartment(dept)}
                      className="py-2.5 px-3 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200 text-center cursor-pointer"
                    >
                      Department Details
                    </button>
                    <button
                      type="button"
                      onClick={() => onOpenBooking(undefined, dept.id)}
                      className="py-2.5 px-3 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors text-center shadow-xs cursor-pointer"
                    >
                      Book In Department
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* QUICK HOTLINE BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-8">
        <div className="bg-slate-100 border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Phone className="w-5 h-5 text-teal-600 shrink-0" />
            <div className="text-xs text-slate-600">
              <span className="font-bold text-slate-900">Unsure which clinical department you need?</span>
              <p>Our nurse triage helpline can review your symptoms and route you to the correct specialist.</p>
            </div>
          </div>
          <a
            href={`tel:${HOSPITAL_INFO.generalPhone.replace(/[^0-9+]/g, '')}`}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold shrink-0"
          >
            Call Outpatient Guidance: {HOSPITAL_INFO.generalPhone}
          </a>
        </div>
      </section>
    </div>
  );
};
