/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { PageId, Doctor, Department, Appointment } from './types/hospital';
import { INITIAL_APPOINTMENTS, DOCTORS, DEPARTMENTS } from './data/hospitalData';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Departments } from './pages/Departments';
import { Doctors } from './pages/Doctors';
import { AdminPortal } from './pages/AdminPortal';
import { AppointmentBookingModal } from './components/AppointmentBookingModal';
import { MyAppointmentsModal } from './components/MyAppointmentsModal';
import { DoctorDetailModal } from './components/DoctorDetailModal';
import { DepartmentDetailModal } from './components/DepartmentDetailModal';
import { AuthModal } from './components/AuthModal';
import { AuthProvider, useAuth } from './context/AuthContext';
import { 
  saveAppointment, 
  getUserAppointments, 
  updateAppointment, 
  getAllAppointments, 
  deleteAppointment 
} from './firebase/firestoreService';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';

const STORAGE_KEY = 'wecare_hospitals_appointments_v1';

function AppContent() {
  const { currentUser, userProfile } = useAuth();
  const [currentPage, setCurrentPage] = useState<PageId>('home');
  const [departmentFilterForDoctors, setDepartmentFilterForDoctors] = useState<string>('all');

  // Appointments State
  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Notice: Error loading appointments from localStorage', e);
    }
    return INITIAL_APPOINTMENTS;
  });

  // Toast notification
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' } | null>(null);

  const showToast = (text: string, type: 'success' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Sync appointments from Firestore
  useEffect(() => {
    async function loadCloudAppointments() {
      const isAdminUser = 
        currentUser?.email?.toLowerCase() === 'sushantanundruka123@gmail.com' ||
        currentPage === 'admin' ||
        sessionStorage.getItem('wecare_admin_logged_in') === 'true';

      try {
        if (isAdminUser) {
          const allApts = await getAllAppointments();
          if (allApts && allApts.length > 0) {
            setAppointments(prev => {
              const map = new Map<string, Appointment>();
              prev.forEach(a => map.set(a.id, a));
              allApts.forEach(a => map.set(a.id, a));
              return Array.from(map.values()).sort(
                (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
              );
            });
          }
        } else if (currentUser?.uid) {
          const cloudApts = await getUserAppointments(currentUser.uid);
          if (cloudApts && cloudApts.length > 0) {
            setAppointments(prev => {
              // Merge cloud with existing, preventing duplicates by ID
              const map = new Map<string, Appointment>();
              prev.forEach(a => map.set(a.id, a));
              cloudApts.forEach(a => map.set(a.id, a));
              return Array.from(map.values()).sort(
                (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
              );
            });
            showToast(`Synchronized ${cloudApts.length} appointment(s) from your medical portal`, 'info');
          }
        }
      } catch (err) {
        console.warn('Could not sync cloud appointments, using offline storage:', err);
      }
    }
    loadCloudAppointments();
  }, [currentUser?.uid, currentUser?.email, currentPage]);

  // Sync appointments to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(appointments));
    } catch (e) {
      console.warn('Notice: localStorage write:', e);
    }
  }, [appointments]);

  // Modal controls
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingDoctorId, setBookingDoctorId] = useState<string | undefined>(undefined);
  const [bookingDepartmentId, setBookingDepartmentId] = useState<string | undefined>(undefined);

  const [isAppointmentsOpen, setIsAppointmentsOpen] = useState(false);
  const [viewingDoctor, setViewingDoctor] = useState<Doctor | null>(null);
  const [viewingDepartment, setViewingDepartment] = useState<Department | null>(null);

  // Auth modal controls
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authIntendedText, setAuthIntendedText] = useState<string | undefined>(undefined);
  const [pendingBookingAction, setPendingBookingAction] = useState<(() => void) | null>(null);

  const handleOpenAuth = (intendedText?: string, onSuccessAction?: () => void) => {
    setAuthIntendedText(intendedText);
    setPendingBookingAction(onSuccessAction ? () => onSuccessAction : null);
    setIsAuthOpen(true);
  };

  // Open booking wizard handler
  const handleOpenBooking = (doctorId?: string, departmentId?: string) => {
    setBookingDoctorId(doctorId);
    setBookingDepartmentId(departmentId);
    setIsBookingOpen(true);
  };

  // Save new appointment handler
  const handleSaveAppointment = async (newAppointment: Appointment) => {
    // 1. Update local state
    setAppointments(prev => [newAppointment, ...prev]);

    // 2. Persist in Firebase Firestore if user is authenticated or has internet
    try {
      await saveAppointment(newAppointment);
    } catch (err) {
      console.warn('Saved appointment locally; cloud sync pending:', err);
    }

    showToast(`Appointment scheduled with ${newAppointment.doctorName} (Ref: ${newAppointment.referenceCode})`, 'success');
  };

  // Cancel appointment handler
  const handleCancelAppointment = async (id: string) => {
    setAppointments(prev =>
      prev.map(apt => (apt.id === id ? { ...apt, status: 'cancelled' } : apt))
    );

    try {
      await updateAppointment(id, { status: 'cancelled' });
    } catch (err) {
      console.warn('Updated cancellation locally; cloud sync error:', err);
    }

    showToast('Appointment has been cancelled', 'info');
  };

  // Reschedule appointment handler
  const handleRescheduleAppointment = async (id: string, newDate: string, newSlot: string) => {
    setAppointments(prev =>
      prev.map(apt =>
        apt.id === id
          ? { ...apt, date: newDate, timeSlot: newSlot, status: 'rescheduled' }
          : apt
      )
    );

    try {
      await updateAppointment(id, { date: newDate, timeSlot: newSlot, status: 'rescheduled' });
    } catch (err) {
      console.warn('Updated reschedule locally; cloud sync error:', err);
    }

    showToast(`Appointment rescheduled to ${newDate} at ${newSlot}`, 'success');
  };

  // Admin update booking handler
  const handleAdminUpdateAppointment = async (updated: Appointment) => {
    setAppointments(prev => prev.map(a => (a.id === updated.id ? updated : a)));
    try {
      await updateAppointment(updated.id, updated);
    } catch (err) {
      console.warn('Updated booking locally; cloud sync pending:', err);
    }
    showToast(`Booking ${updated.referenceCode} updated`, 'info');
  };

  // Admin delete booking handler
  const handleDeleteAppointment = async (id: string) => {
    setAppointments(prev => prev.filter(a => a.id !== id));
    try {
      await deleteAppointment(id);
    } catch (err) {
      console.warn('Deleted locally; cloud delete error:', err);
    }
    showToast('Hospital booking removed from records', 'info');
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-5 duration-200">
          <div className="bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-slate-800 flex items-center gap-3 text-xs max-w-md">
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <span className="flex-1 font-medium">{toastMessage.text}</span>
            <button
              onClick={() => setToastMessage(null)}
              className="text-slate-400 hover:text-white p-0.5 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Top Bar Navigation */}
      <Navbar
        currentPage={currentPage}
        onNavigate={(page) => {
          setCurrentPage(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenBooking={(docId, deptId) => handleOpenBooking(docId, deptId)}
        onOpenAppointments={() => setIsAppointmentsOpen(true)}
        onOpenAuth={() => handleOpenAuth()}
        appointmentCount={appointments.filter(a => a.status !== 'cancelled').length}
      />

      {/* Main Page Routing */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <Home
            onNavigate={(page) => {
              setCurrentPage(page);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenBooking={handleOpenBooking}
            onViewDoctorProfile={(doc) => setViewingDoctor(doc)}
          />
        )}

        {currentPage === 'about' && (
          <About
            onNavigate={(page) => {
              setCurrentPage(page);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenBooking={() => handleOpenBooking()}
          />
        )}

        {currentPage === 'departments' && (
          <Departments
            onNavigate={(page) => {
              setCurrentPage(page);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenBooking={handleOpenBooking}
            onSelectDepartment={(dept) => setViewingDepartment(dept)}
            onViewDoctorProfile={(doc) => setViewingDoctor(doc)}
          />
        )}

        {currentPage === 'doctors' && (
          <Doctors
            onNavigate={(page) => {
              setCurrentPage(page);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenBooking={handleOpenBooking}
            onViewDoctorProfile={(doc) => setViewingDoctor(doc)}
            initialDepartmentFilter={departmentFilterForDoctors}
          />
        )}

        {currentPage === 'admin' && (
          <AdminPortal
            appointments={appointments}
            onNavigate={(page) => {
              setCurrentPage(page);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSaveAppointment={handleSaveAppointment}
            onUpdateAppointment={handleAdminUpdateAppointment}
            onDeleteAppointment={handleDeleteAppointment}
          />
        )}
      </main>

      {/* Shared Footer */}
      <Footer
        onNavigate={(page) => {
          setCurrentPage(page);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenBooking={() => handleOpenBooking()}
        onOpenAppointments={() => setIsAppointmentsOpen(true)}
      />

      {/* MODALS */}
      {/* 1. Appointment Booking Wizard */}
      <AppointmentBookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        initialDoctorId={bookingDoctorId}
        initialDepartmentId={bookingDepartmentId}
        onSaveAppointment={handleSaveAppointment}
        onViewAppointments={() => setIsAppointmentsOpen(true)}
        onOpenAuth={(text) => handleOpenAuth(text)}
      />

      {/* 2. My Bookings / Appointments Modal */}
      <MyAppointmentsModal
        isOpen={isAppointmentsOpen}
        onClose={() => setIsAppointmentsOpen(false)}
        appointments={appointments}
        onCancelAppointment={handleCancelAppointment}
        onRescheduleAppointment={handleRescheduleAppointment}
        onOpenBooking={() => handleOpenBooking()}
        onOpenAuth={(text) => handleOpenAuth(text)}
      />

      {/* 3. Doctor Details Modal */}
      <DoctorDetailModal
        doctor={viewingDoctor}
        onClose={() => setViewingDoctor(null)}
        onBookAppointment={(docId, deptId) => {
          setViewingDoctor(null);
          handleOpenBooking(docId, deptId);
        }}
      />

      {/* 4. Department Details & Doctors Modal */}
      <DepartmentDetailModal
        department={viewingDepartment}
        doctors={DOCTORS}
        onClose={() => setViewingDepartment(null)}
        onBookAppointment={(docId, deptId) => {
          setViewingDepartment(null);
          handleOpenBooking(docId, deptId);
        }}
        onViewDoctorProfile={(doc) => {
          setViewingDepartment(null);
          setViewingDoctor(doc);
        }}
      />

      {/* 5. Patient Authentication Modal (Sign In & Sign Up) */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => {
          setIsAuthOpen(false);
          setPendingBookingAction(null);
        }}
        onSuccess={() => {
          if (pendingBookingAction) {
            pendingBookingAction();
          }
          showToast('Welcome to your WeCare patient portal', 'success');
        }}
        intendedActionText={authIntendedText}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
