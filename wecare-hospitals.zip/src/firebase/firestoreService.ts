import { 
  doc, setDoc, getDoc, collection, query, where, getDocs, updateDoc, deleteDoc 
} from 'firebase/firestore';
import { db } from './firebase';
import { Appointment } from '../types/hospital';

export interface UserProfileData {
  uid: string;
  email: string;
  displayName: string;
  phoneNumber?: string;
  createdAt: string;
  role: 'patient' | 'admin';
}

const LOCAL_APPOINTMENTS_KEY = 'wecare_hospitals_appointments_v1';
const ADMIN_EMAIL = 'sushantanundruka123@gmail.com';

/**
 * Creates or updates patient profile in /users/{userId}
 * Falls back to local storage if remote Firestore rules are not yet configured.
 */
export async function saveUserProfile(
  uid: string, 
  data: { email: string; displayName: string; phoneNumber?: string }
): Promise<void> {
  const isAdmin = data.email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
  const profile: UserProfileData = {
    uid,
    email: data.email,
    displayName: data.displayName || (isAdmin ? 'Hospital Administrator' : 'Patient'),
    phoneNumber: data.phoneNumber || '',
    createdAt: new Date().toISOString(),
    role: isAdmin ? 'admin' : 'patient'
  };

  // Cache locally immediately so user data is never lost
  try {
    localStorage.setItem(`wecare_profile_${uid}`, JSON.stringify(profile));
  } catch (e) {
    // ignore local storage errors
  }

  try {
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, {
      uid,
      email: data.email,
      displayName: data.displayName || (isAdmin ? 'Hospital Administrator' : 'Patient'),
      phoneNumber: data.phoneNumber || '',
      role: isAdmin ? 'admin' : 'patient',
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (error: any) {
    console.warn('Notice: Firestore user write was stored locally:', error?.message || error);
  }
}

/**
 * Retrieves patient profile from /users/{userId} with local cache fallback
 */
export async function getUserProfile(uid: string): Promise<UserProfileData | null> {
  // Check cloud first
  try {
    const userRef = doc(db, 'users', uid);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      const data = snap.data() as UserProfileData;
      try {
        localStorage.setItem(`wecare_profile_${uid}`, JSON.stringify(data));
      } catch (e) {}
      return data;
    }
  } catch (error: any) {
    console.warn('Notice: Reading user profile from local storage (Firebase console rules pending):', error?.message || error);
  }

  // Fallback to locally cached profile
  try {
    const cached = localStorage.getItem(`wecare_profile_${uid}`);
    if (cached) {
      return JSON.parse(cached);
    }
  } catch (e) {}

  return null;
}

/**
 * Saves a new appointment to /appointments/{appointmentId}
 * Synchronizes to both local storage and Firestore.
 */
export async function saveAppointment(appointment: Appointment): Promise<void> {
  // 1. Always update local storage first
  try {
    const saved = localStorage.getItem(LOCAL_APPOINTMENTS_KEY);
    const existing: Appointment[] = saved ? JSON.parse(saved) : [];
    const updated = [appointment, ...existing.filter(a => a.id !== appointment.id)];
    localStorage.setItem(LOCAL_APPOINTMENTS_KEY, JSON.stringify(updated));
  } catch (e) {}

  // 2. Try persisting to Firestore
  try {
    const appointmentRef = doc(db, 'appointments', appointment.id);
    await setDoc(appointmentRef, {
      ...appointment,
      updatedAt: new Date().toISOString()
    });
  } catch (error: any) {
    console.warn('Notice: Appointment saved locally; Firestore write pending:', error?.message || error);
  }
}

/**
 * Fetches all appointments booked by a specific user from /appointments
 * Merges cloud appointments with locally cached appointments.
 */
export async function getUserAppointments(userId: string): Promise<Appointment[]> {
  const localList: Appointment[] = [];
  try {
    const saved = localStorage.getItem(LOCAL_APPOINTMENTS_KEY);
    if (saved) {
      const parsed: Appointment[] = JSON.parse(saved);
      localList.push(...parsed.filter(a => a.userId === userId || !a.userId));
    }
  } catch (e) {}

  try {
    const appointmentsCol = collection(db, 'appointments');
    const q = query(appointmentsCol, where('userId', '==', userId));
    const querySnapshot = await getDocs(q);

    const cloudAppointments: Appointment[] = [];
    querySnapshot.forEach((docSnap) => {
      cloudAppointments.push(docSnap.data() as Appointment);
    });

    if (cloudAppointments.length > 0) {
      // Merge with local avoiding duplicates
      const map = new Map<string, Appointment>();
      localList.forEach(a => map.set(a.id, a));
      cloudAppointments.forEach(a => map.set(a.id, a));
      return Array.from(map.values()).sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    }
  } catch (error: any) {
    console.warn('Notice: Loaded appointments from local storage (Firestore permissions pending):', error?.message || error);
  }

  return localList;
}

/**
 * Updates an appointment (reschedule, cancel) in /appointments/{appointmentId}
 */
export async function updateAppointment(
  appointmentId: string, 
  updates: Partial<Appointment>
): Promise<void> {
  // Update local storage
  try {
    const saved = localStorage.getItem(LOCAL_APPOINTMENTS_KEY);
    if (saved) {
      const existing: Appointment[] = JSON.parse(saved);
      const updated = existing.map(apt => 
        apt.id === appointmentId ? { ...apt, ...updates, updatedAt: new Date().toISOString() } : apt
      );
      localStorage.setItem(LOCAL_APPOINTMENTS_KEY, JSON.stringify(updated));
    }
  } catch (e) {}

  // Attempt to update Firestore
  try {
    const appointmentRef = doc(db, 'appointments', appointmentId);
    await updateDoc(appointmentRef, {
      ...updates,
      updatedAt: new Date().toISOString()
    });
  } catch (error: any) {
    console.warn('Notice: Appointment updated locally; Firestore write pending:', error?.message || error);
  }
}

/**
 * Fetches all appointments from /appointments for administration desk.
 * Merges with locally cached appointments.
 */
export async function getAllAppointments(): Promise<Appointment[]> {
  const localList: Appointment[] = [];
  try {
    const saved = localStorage.getItem(LOCAL_APPOINTMENTS_KEY);
    if (saved) {
      const parsed: Appointment[] = JSON.parse(saved);
      localList.push(...parsed);
    }
  } catch (e) {}

  try {
    const appointmentsCol = collection(db, 'appointments');
    const querySnapshot = await getDocs(appointmentsCol);

    const cloudAppointments: Appointment[] = [];
    querySnapshot.forEach((docSnap) => {
      cloudAppointments.push(docSnap.data() as Appointment);
    });

    if (cloudAppointments.length > 0) {
      const map = new Map<string, Appointment>();
      localList.forEach(a => map.set(a.id, a));
      cloudAppointments.forEach(a => map.set(a.id, a));
      return Array.from(map.values()).sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    }
  } catch (error: any) {
    console.warn('Notice: Loading appointments from local cache:', error?.message || error);
  }

  return localList;
}

/**
 * Deletes an appointment from /appointments/{appointmentId} and local storage
 */
export async function deleteAppointment(appointmentId: string): Promise<void> {
  // Update local storage
  try {
    const saved = localStorage.getItem(LOCAL_APPOINTMENTS_KEY);
    if (saved) {
      const existing: Appointment[] = JSON.parse(saved);
      const filtered = existing.filter(a => a.id !== appointmentId);
      localStorage.setItem(LOCAL_APPOINTMENTS_KEY, JSON.stringify(filtered));
    }
  } catch (e) {}

  // Delete from Firestore
  try {
    const appointmentRef = doc(db, 'appointments', appointmentId);
    await deleteDoc(appointmentRef);
  } catch (error: any) {
    console.warn('Notice: Appointment deleted locally; Firestore delete pending:', error?.message || error);
  }
}

