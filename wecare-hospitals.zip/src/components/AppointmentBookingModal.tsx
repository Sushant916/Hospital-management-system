import React, { useState, useEffect, useMemo } from 'react';
import { Doctor, Department, Appointment } from '../types/hospital';
import { DEPARTMENTS, DOCTORS, HOSPITAL_INFO } from '../data/hospitalData';
import { 
  X, Calendar, Clock, User, Phone, Mail, FileText, CheckCircle2, 
  Video, Building2, AlertCircle, ArrowLeft, ArrowRight, Download, CalendarPlus, Stethoscope, LogIn, ShieldCheck
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface AppointmentBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDoctorId?: string;
  initialDepartmentId?: string;
  onSaveAppointment: (appointment: Appointment) => void;
  onViewAppointments: () => void;
  onOpenAuth: (text?: string) => void;
}

export const AppointmentBookingModal: React.FC<AppointmentBookingModalProps> = ({
  isOpen,
  onClose,
  initialDoctorId,
  initialDepartmentId,
  onSaveAppointment,
  onViewAppointments,
  onOpenAuth
}) => {
  const { currentUser, userProfile } = useAuth();

  // Step state: 1 = Doctor/Dept, 2 = Date/Time, 3 = Patient Info, 4 = Confirmation
  const [step, setStep] = useState<number>(1);

  // Form State
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<string>('');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('');
  const [consultationType, setConsultationType] = useState<'in-person' | 'telehealth'>('in-person');
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('');
  
  // Patient details
  const [patientName, setPatientName] = useState<string>('');
  const [patientEmail, setPatientEmail] = useState<string>('');
  const [patientPhone, setPatientPhone] = useState<string>('');
  const [patientAge, setPatientAge] = useState<string>('34');
  const [patientGender, setPatientGender] = useState<'male' | 'female' | 'other' | 'prefer-not-to-say'>('female');
  const [isExistingPatient, setIsExistingPatient] = useState<boolean>(false);
  const [reason, setReason] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  // Confirmed appointment result
  const [confirmedAppointment, setConfirmedAppointment] = useState<Appointment | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Reset or initialize on open
  useEffect(() => {
    if (isOpen) {
      if (initialDoctorId) {
        const doc = DOCTORS.find(d => d.id === initialDoctorId);
        if (doc) {
          setSelectedDoctorId(doc.id);
          setSelectedDepartmentId(doc.departmentId);
          setStep(2); // Jump straight to date & time
        }
      } else if (initialDepartmentId) {
        setSelectedDepartmentId(initialDepartmentId);
        setSelectedDoctorId('');
        setStep(1);
      } else {
        setSelectedDepartmentId(DEPARTMENTS[0].id);
        setSelectedDoctorId('');
        setStep(1);
      }
      setConfirmedAppointment(null);
      setErrors({});

      // Prepopulate from authenticated user profile
      if (currentUser) {
        if (userProfile?.displayName || currentUser.displayName) {
          setPatientName(userProfile?.displayName || currentUser.displayName || '');
        }
        if (currentUser.email) {
          setPatientEmail(currentUser.email);
        }
        if (userProfile?.phoneNumber) {
          setPatientPhone(userProfile.phoneNumber);
        }
      }
    }
  }, [isOpen, initialDoctorId, initialDepartmentId, currentUser, userProfile]);

  // Doctors in selected department
  const filteredDoctors = useMemo(() => {
    if (!selectedDepartmentId) return DOCTORS;
    return DOCTORS.filter(d => d.departmentId === selectedDepartmentId);
  }, [selectedDepartmentId]);

  const selectedDoctor = useMemo(() => {
    return DOCTORS.find(d => d.id === selectedDoctorId);
  }, [selectedDoctorId]);

  const selectedDepartment = useMemo(() => {
    return DEPARTMENTS.find(d => d.id === selectedDepartmentId);
  }, [selectedDepartmentId]);

  // Generate next 14 available dates
  const availableDates = useMemo(() => {
    const dates = [];
    const today = new Date();
    // Start tomorrow or today
    for (let i = 1; i <= 14; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);
      const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
      const dateString = d.toISOString().split('T')[0];
      const displayString = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', weekday: 'short' });
      
      // Check if selected doctor practices on this day
      const isAvailableForDoctor = selectedDoctor 
        ? selectedDoctor.availableDays.includes(dayName)
        : true;

      dates.push({
        dateString,
        displayString,
        dayName,
        isAvailable: isAvailableForDoctor
      });
    }
    return dates;
  }, [selectedDoctor]);

  // Default date selection if not set
  useEffect(() => {
    if (selectedDoctor && availableDates.length > 0) {
      const firstValidDate = availableDates.find(d => d.isAvailable);
      if (firstValidDate && !selectedDate) {
        setSelectedDate(firstValidDate.dateString);
      }
    }
  }, [selectedDoctor, availableDates, selectedDate]);

  // Available time slots
  const availableSlots = useMemo(() => {
    if (selectedDoctor) {
      return selectedDoctor.timeSlots;
    }
    return ['09:00 AM', '10:00 AM', '11:30 AM', '02:00 PM', '03:30 PM', '04:30 PM'];
  }, [selectedDoctor]);

  // Set default time slot
  useEffect(() => {
    if (availableSlots.length > 0 && !selectedTimeSlot) {
      setSelectedTimeSlot(availableSlots[0]);
    }
  }, [availableSlots, selectedTimeSlot]);

  if (!isOpen) return null;

  // Validate step 3 before submission
  const validatePatientInfo = () => {
    const newErrors: Record<string, string> = {};
    if (!patientName.trim()) newErrors.name = 'Patient name is required';
    if (!patientPhone.trim()) {
      newErrors.phone = 'Contact phone number is required';
    } else if (patientPhone.replace(/[^0-9]/g, '').length < 8) {
      newErrors.phone = 'Please enter a valid phone number';
    }
    if (!patientEmail.trim() || !patientEmail.includes('@')) {
      newErrors.email = 'Valid email is required for confirmation';
    }
    if (!selectedDate) newErrors.date = 'Appointment date is required';
    if (!selectedTimeSlot) newErrors.slot = 'Time slot is required';
    if (!reason.trim()) newErrors.reason = 'Please provide a brief reason or symptom for consultation';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleConfirmBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validatePatientInfo()) return;
    if (!selectedDoctor || !selectedDepartment) return;

    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const referenceCode = `WCH-${randomSuffix}`;

    const newAppointment: Appointment = {
      id: `apt-${Date.now()}`,
      referenceCode,
      userId: currentUser?.uid,
      userEmail: currentUser?.email || patientEmail.trim(),
      doctorId: selectedDoctor.id,
      doctorName: selectedDoctor.name,
      doctorTitle: selectedDoctor.title,
      departmentId: selectedDepartment.id,
      departmentName: selectedDepartment.name,
      patientName: patientName.trim(),
      patientEmail: patientEmail.trim(),
      patientPhone: patientPhone.trim(),
      patientAge: parseInt(patientAge, 10) || 30,
      patientGender,
      isExistingPatient,
      date: selectedDate,
      timeSlot: selectedTimeSlot,
      consultationType,
      reason: reason.trim(),
      notes: notes.trim() || undefined,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
      consultationFee: selectedDoctor.consultationFee,
      roomNumber: consultationType === 'in-person' ? `Clinic Wing ${selectedDepartment.floor.split(',')[0]}, Room 204` : undefined
    };

    onSaveAppointment(newAppointment);
    setConfirmedAppointment(newAppointment);
    setStep(4);
  };

  // Generate calendar .ics file download
  const handleDownloadCalendar = () => {
    if (!confirmedAppointment) return;
    const icsContent = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//WeCare Hospitals//Appointment//EN
BEGIN:VEVENT
SUMMARY:Medical Appointment with ${confirmedAppointment.doctorName}
DESCRIPTION:Consultation: ${confirmedAppointment.reason}\\nDepartment: ${confirmedAppointment.departmentName}\\nReference: ${confirmedAppointment.referenceCode}
LOCATION:${confirmedAppointment.consultationType === 'in-person' ? HOSPITAL_INFO.address : 'Secure Telehealth Video Call'}
DTSTART:${confirmedAppointment.date.replace(/-/g, '')}T090000
DTEND:${confirmedAppointment.date.replace(/-/g, '')}T100000
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.setAttribute('download', `wecare-appointment-${confirmedAppointment.referenceCode}.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="px-6 py-4.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
              <Calendar className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display tracking-tight text-white">
                {step === 4 ? 'Appointment Confirmed' : 'Book a Medical Appointment'}
              </h3>
              <p className="text-xs text-slate-400">
                {step === 4 
                  ? 'Your appointment has been reserved in our hospital schedule' 
                  : 'Fast, confidential scheduling with our board-certified specialists'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
            aria-label="Close booking modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Multi-step progress bar (steps 1 to 3) */}
        {step < 4 && (
          <div className="border-b border-slate-100 bg-slate-50/70 px-6 py-3">
            <div className="flex items-center justify-between text-xs font-medium text-slate-600">
              <div className={`flex items-center gap-2 ${step >= 1 ? 'text-teal-700 font-semibold' : ''}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${step >= 1 ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-600'}`}>1</span>
                <span>Specialist</span>
              </div>
              <div className="h-0.5 w-8 bg-slate-200" />
              <div className={`flex items-center gap-2 ${step >= 2 ? 'text-teal-700 font-semibold' : ''}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${step >= 2 ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-600'}`}>2</span>
                <span>Date & Time</span>
              </div>
              <div className="h-0.5 w-8 bg-slate-200" />
              <div className={`flex items-center gap-2 ${step >= 3 ? 'text-teal-700 font-semibold' : ''}`}>
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-xs ${step >= 3 ? 'bg-teal-600 text-white' : 'bg-slate-200 text-slate-600'}`}>3</span>
                <span>Patient Info</span>
              </div>
            </div>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6">
          {/* STEP 1: Select Department & Doctor */}
          {step === 1 && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                  Select Clinical Department
                </label>
                <select
                  value={selectedDepartmentId}
                  onChange={(e) => {
                    setSelectedDepartmentId(e.target.value);
                    setSelectedDoctorId(''); // reset doctor selection
                  }}
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                >
                  {DEPARTMENTS.map((dept) => (
                    <option key={dept.id} value={dept.id}>
                      {dept.name} ({dept.floor})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                  Choose Consulting Doctor ({filteredDoctors.length} Available)
                </label>
                <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                  {filteredDoctors.map((doc) => {
                    const isSelected = selectedDoctorId === doc.id;
                    return (
                      <div
                        key={doc.id}
                        onClick={() => setSelectedDoctorId(doc.id)}
                        className={`p-3.5 rounded-xl border text-left cursor-pointer transition-all ${
                          isSelected
                            ? 'border-teal-600 bg-teal-50/50 ring-1 ring-teal-600 shadow-xs'
                            : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-teal-700 font-bold text-sm shrink-0">
                              {doc.name.split(' ').slice(1).map(n => n[0]).join('')}
                            </div>
                            <div>
                              <h4 className="text-sm font-bold text-slate-900">{doc.name}</h4>
                              <p className="text-xs text-slate-500">{doc.title}</p>
                              <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                                <span>{doc.experienceYears} yrs exp</span>
                                <span aria-hidden="true">·</span>
                                <span>⭐ {doc.rating.toFixed(1)} ({doc.reviewCount})</span>
                                <span aria-hidden="true">·</span>
                                <span className="font-semibold text-teal-700">${doc.consultationFee} fee</span>
                              </div>
                            </div>
                          </div>
                          <div className="shrink-0 text-right">
                            <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                              Available
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  disabled={!selectedDoctorId}
                  onClick={() => setStep(2)}
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Continue to Date & Time</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Date, Time & Consultation Mode */}
          {step === 2 && (
            <div className="space-y-5">
              {/* Doctor Summary Bar */}
              {selectedDoctor && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-full bg-teal-100 text-teal-800 font-bold text-xs flex items-center justify-center">
                      {selectedDoctor.name.split(' ').slice(1).map(n => n[0]).join('')}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-slate-900">{selectedDoctor.name}</p>
                      <p className="text-xs text-slate-500">{selectedDoctor.departmentName} · ${selectedDoctor.consultationFee}</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="text-xs font-semibold text-teal-600 hover:text-teal-800 underline"
                  >
                    Change
                  </button>
                </div>
              )}

              {/* Consultation Mode */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                  Consultation Mode
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setConsultationType('in-person')}
                    className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-colors cursor-pointer ${
                      consultationType === 'in-person'
                        ? 'border-teal-600 bg-teal-50/60 ring-1 ring-teal-600'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Building2 className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-sm font-bold text-slate-900">Hospital In-Person</div>
                      <p className="text-xs text-slate-500 mt-0.5">WeCare Medical Campus Suite</p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setConsultationType('telehealth')}
                    className={`p-3 rounded-xl border text-left flex items-start gap-3 transition-colors cursor-pointer ${
                      consultationType === 'telehealth'
                        ? 'border-teal-600 bg-teal-50/60 ring-1 ring-teal-600'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Video className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                    <div>
                      <div className="text-sm font-bold text-slate-900">Video Telehealth</div>
                      <p className="text-xs text-slate-500 mt-0.5">Secure HD Video link via SMS/email</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Date Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                  Select Appointment Date
                </label>
                <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                  {availableDates.slice(0, 7).map((d) => {
                    const isSelected = selectedDate === d.dateString;
                    return (
                      <button
                        key={d.dateString}
                        type="button"
                        disabled={!d.isAvailable}
                        onClick={() => setSelectedDate(d.dateString)}
                        className={`p-2 rounded-lg text-center border transition-all cursor-pointer ${
                          !d.isAvailable
                            ? 'opacity-40 bg-slate-100 border-slate-200 cursor-not-allowed'
                            : isSelected
                            ? 'border-teal-600 bg-teal-600 text-white shadow-xs font-semibold'
                            : 'border-slate-200 hover:border-teal-500 hover:bg-teal-50/30 text-slate-800'
                        }`}
                      >
                        <div className={`text-xs ${isSelected ? 'text-teal-100' : 'text-slate-400'}`}>
                          {d.dayName}
                        </div>
                        <div className="text-sm font-bold mt-0.5">
                          {d.displayString.split(' ')[1]}
                        </div>
                      </button>
                    );
                  })}
                </div>
                {errors.date && <p className="text-xs text-rose-600 mt-1">{errors.date}</p>}
              </div>

              {/* Time Slot Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                  Select Available Time Slot
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                  {availableSlots.map((slot) => {
                    const isSelected = selectedTimeSlot === slot;
                    return (
                      <button
                        key={slot}
                        type="button"
                        onClick={() => setSelectedTimeSlot(slot)}
                        className={`py-2 px-2.5 rounded-lg text-xs font-semibold border text-center transition-colors cursor-pointer ${
                          isSelected
                            ? 'border-teal-600 bg-teal-50 text-teal-800 ring-1 ring-teal-600'
                            : 'border-slate-200 hover:border-slate-300 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <Clock className="w-3.5 h-3.5 inline mr-1 text-slate-400" />
                        {slot}
                      </button>
                    );
                  })}
                </div>
                {errors.slot && <p className="text-xs text-rose-600 mt-1">{errors.slot}</p>}
              </div>

              {/* Navigation buttons */}
              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  disabled={!selectedDate || !selectedTimeSlot}
                  onClick={() => setStep(3)}
                  className="px-5 py-2.5 text-sm font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Continue to Patient Details</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Patient Information Form */}
          {step === 3 && (
            <form onSubmit={handleConfirmBooking} className="space-y-4">
              {/* Authentication Status Banner */}
              {currentUser ? (
                <div className="p-3 bg-teal-50 border border-teal-200 rounded-xl flex items-center justify-between text-xs text-teal-900">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                    <span>
                      Booking linked to Patient Account: <strong>{userProfile?.displayName || currentUser.displayName || currentUser.email}</strong>
                    </span>
                  </div>
                  <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-white text-teal-700 border border-teal-200">
                    Firebase Verified
                  </span>
                </div>
              ) : (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs text-amber-900">
                  <div className="flex items-start gap-2">
                    <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Have a WeCare patient account?</span>
                      <p className="text-amber-800 text-2xs mt-0.5">
                        Sign in or register to securely save this booking in your medical portal.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onOpenAuth('Sign in or register to link this appointment to your account')}
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold whitespace-nowrap self-start sm:self-auto cursor-pointer flex items-center gap-1.5 shadow-2xs"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>Sign In / Register</span>
                  </button>
                </div>
              )}

              {/* Summary Bar */}
              <div className="p-3 bg-teal-50/60 rounded-xl border border-teal-200 text-xs text-teal-900 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="font-bold">{selectedDoctor?.name}</span> · {selectedDepartment?.name}
                </div>
                <div className="flex items-center gap-2 font-medium">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{selectedDate} at {selectedTimeSlot}</span>
                  <span className="uppercase text-slate-500 font-bold text-2xs px-1.5 py-0.5 rounded bg-white">
                    {consultationType}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Patient Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rachel Adams"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                  />
                  {errors.name && <p className="text-xs text-rose-600 mt-1">{errors.name}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Mobile Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="+1 (555) 000-0000"
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                  />
                  {errors.phone && <p className="text-xs text-rose-600 mt-1">{errors.phone}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="rachel.adams@example.com"
                    value={patientEmail}
                    onChange={(e) => setPatientEmail(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                  />
                  {errors.email && <p className="text-xs text-rose-600 mt-1">{errors.email}</p>}
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Age
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="120"
                      value={patientAge}
                      onChange={(e) => setPatientAge(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Gender
                    </label>
                    <select
                      value={patientGender}
                      onChange={(e) => setPatientGender(e.target.value as any)}
                      className="w-full px-2.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                    >
                      <option value="female">Female</option>
                      <option value="male">Male</option>
                      <option value="other">Other</option>
                      <option value="prefer-not-to-say">Prefer not to say</option>
                    </select>
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Primary Reason for Consultation / Symptoms *
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="e.g. Experiencing persistent joint stiffness in knee during morning walking; need orthopedic assessment."
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                />
                {errors.reason && <p className="text-xs text-rose-600 mt-1">{errors.reason}</p>}
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="existingPatient"
                  checked={isExistingPatient}
                  onChange={(e) => setIsExistingPatient(e.target.checked)}
                  className="rounded border-slate-300 text-teal-600 focus:ring-teal-500 h-4 w-4"
                />
                <label htmlFor="existingPatient" className="text-xs text-slate-600 cursor-pointer">
                  I have consulted at WeCare Hospitals before (Existing Patient)
                </label>
              </div>

              <div className="pt-2 flex items-center justify-between border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 text-sm font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors shadow-sm shadow-teal-600/30 flex items-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Confirm & Book Appointment</span>
                </button>
              </div>
            </form>
          )}

          {/* STEP 4: Success & Confirmation */}
          {step === 4 && confirmedAppointment && (
            <div className="space-y-5 text-center">
              <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-xs">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div>
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full">
                  Status: Confirmed
                </span>
                <h4 className="text-xl font-bold font-display text-slate-900 mt-2">
                  Appointment Successfully Scheduled
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  A confirmation SMS & calendar invite have been dispatched to {confirmedAppointment.patientPhone}
                </p>
              </div>

              {/* Pass Card */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-left space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <div>
                    <span className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Booking Reference</span>
                    <p className="text-base font-extrabold text-teal-700 font-mono">{confirmedAppointment.referenceCode}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-2xs uppercase tracking-wider text-slate-400 font-bold">Consultation Fee</span>
                    <p className="text-sm font-bold text-slate-900">${confirmedAppointment.consultationFee}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-400 block">Doctor</span>
                    <span className="font-bold text-slate-900">{confirmedAppointment.doctorName}</span>
                    <span className="text-slate-500 block">{confirmedAppointment.departmentName}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Date & Time</span>
                    <span className="font-bold text-slate-900">{confirmedAppointment.date}</span>
                    <span className="text-teal-700 font-semibold block">{confirmedAppointment.timeSlot}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Patient</span>
                    <span className="font-bold text-slate-900">{confirmedAppointment.patientName}</span>
                    <span className="text-slate-500 block">{confirmedAppointment.patientPhone}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block">Location / Mode</span>
                    <span className="font-bold text-slate-900 capitalize">{confirmedAppointment.consultationType}</span>
                    <span className="text-slate-500 block">
                      {confirmedAppointment.roomNumber || 'Secure Video Telehealth'}
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200 text-xs text-slate-500 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span>
                    Please arrive 15 minutes before your slot with government-issued photo ID and any prior diagnostic imaging.
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleDownloadCalendar}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <CalendarPlus className="w-4 h-4 text-teal-600" />
                  <span>Add to Calendar (.ics)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onViewAppointments();
                  }}
                  className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-4 h-4" />
                  <span>View in My Bookings</span>
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-teal-700 bg-teal-50 rounded-lg hover:bg-teal-100 transition-colors cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
