import React from 'react';
import { Department, Doctor } from '../types/hospital';
import { 
  X, Calendar, Stethoscope, Building2, ShieldCheck, 
  Cpu, Phone, MapPin, ChevronRight, CheckCircle2 
} from 'lucide-react';

interface DepartmentDetailModalProps {
  department: Department | null;
  doctors: Doctor[];
  onClose: () => void;
  onBookAppointment: (doctorId?: string, departmentId?: string) => void;
  onViewDoctorProfile: (doctor: Doctor) => void;
}

export const DepartmentDetailModal: React.FC<DepartmentDetailModalProps> = ({
  department,
  doctors,
  onClose,
  onBookAppointment,
  onViewDoctorProfile
}) => {
  if (!department) return null;

  const departmentDoctors = doctors.filter(d => d.departmentId === department.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden my-auto animate-in fade-in duration-150">
        
        {/* Header Bar */}
        <div className="px-6 py-4.5 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold font-display text-white">{department.name}</h3>
            <p className="text-xs text-teal-400 font-medium">{department.tagline}</p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
          {/* Overview text */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Clinical Department Overview
            </h4>
            <p className="text-sm text-slate-700 leading-relaxed">
              {department.fullDescription}
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block font-medium">Head of Department</span>
              <span className="font-bold text-slate-800">{department.headDoctorName}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Location</span>
              <span className="font-bold text-slate-800">{department.floor}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Inpatient Beds</span>
              <span className="font-bold text-slate-800">{department.bedCount} Dedicated Beds</span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Emergency Cover</span>
              <span className="font-bold text-emerald-700">
                {department.emergencyAvailable ? '24/7 Rapid Triage' : 'Outpatient Scheduled'}
              </span>
            </div>
          </div>

          {/* Advanced Technologies */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-teal-600" />
              Advanced Technologies & Infrastructure
            </h4>
            <div className="flex flex-wrap gap-2">
              {department.technologies.map((tech, i) => (
                <span
                  key={i}
                  className="px-2.5 py-1 bg-slate-100 border border-slate-200 text-slate-700 text-xs rounded-md font-medium"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>

          {/* Treatments & Surgeries */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Specialized Procedures & Interventions
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {department.treatments.map((treatment, i) => (
                <div key={i} className="flex items-center gap-2 text-slate-700 p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                  <span>{treatment}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Specialists in this department */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Specialists in this Department ({departmentDoctors.length})
              </h4>
            </div>

            <div className="space-y-2.5">
              {departmentDoctors.map((doc) => (
                <div
                  key={doc.id}
                  className="p-3 bg-white border border-slate-200 rounded-xl flex items-center justify-between gap-3 hover:border-slate-300 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-teal-50 border border-teal-200 text-teal-800 font-bold text-xs flex items-center justify-center shrink-0">
                      {doc.name.split(' ').slice(1).map(n => n[0]).join('')}
                    </div>
                    <div>
                      <h5 className="text-sm font-bold text-slate-900">{doc.name}</h5>
                      <p className="text-xs text-slate-500">{doc.title}</p>
                      <div className="flex items-center gap-2 text-2xs text-slate-400 mt-0.5">
                        <span>{doc.experienceYears} yrs exp</span>
                        <span aria-hidden="true">·</span>
                        <span>⭐ {doc.rating.toFixed(1)}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-semibold text-slate-700">${doc.consultationFee}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onViewDoctorProfile(doc);
                      }}
                      className="px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg hover:bg-slate-50"
                    >
                      Profile
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onBookAppointment(doc.id, department.id);
                      }}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors shadow-2xs"
                    >
                      Book Visit
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Phone className="w-3.5 h-3.5 text-teal-600" />
            <span>Direct Department Line: {department.phone}</span>
          </div>
          <button
            onClick={() => {
              onClose();
              onBookAppointment(undefined, department.id);
            }}
            className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer shadow-sm shadow-teal-600/30"
          >
            <Calendar className="w-4 h-4" />
            <span>Book in this Department</span>
          </button>
        </div>
      </div>
    </div>
  );
};
