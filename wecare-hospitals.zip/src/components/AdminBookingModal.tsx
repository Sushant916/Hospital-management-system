import React, { useState, useMemo } from 'react';
import { Appointment, Doctor, Department } from '../types/hospital';
import { DEPARTMENTS, DOCTORS, HOSPITAL_INFO } from '../data/hospitalData';
import { 
  X, Calendar, Clock, User, Phone, Mail, Building2, 
  Stethoscope, CheckCircle2, AlertCircle, DollarSign, FileText, Video
} from 'lucide-react';

interface AdminBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveBooking: (booking: Appointment) => void;
}

export const AdminBookingModal: React.FC<AdminBookingModalProps> = ({
  isOpen,
  onClose,
  onSaveBooking
}) => {
  const [patientName, setPatientName] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [patientEmail, setPatientEmail] = useState('');
  const [patientAge, setPatientAge] = useState('35');
  const [patientGender, setPatientGender] = useState<'male' | 'female' | 'other' | 'prefer-not-to-say'>('female');
  const [isExistingPatient, setIsExistingPatient] = useState(false);

  const [selectedDeptId, setSelectedDeptId] = useState(DEPARTMENTS[0].id);
  const [selectedDocId, setSelectedDocId] = useState(DOCTORS[0].id);
  const [consultationType, setConsultationType] = useState<'in-person' | 'telehealth'>('in-person');
  const [roomNumber, setRoomNumber] = useState('Suite 204, East Wing');
  
  // Tomorrow's date by default
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const [bookingDate, setBookingDate] = useState(tomorrow.toISOString().split('T')[0]);
  const [timeSlot, setTimeSlot] = useState('10:00 AM');
  const [fee, setFee] = useState<number>(DOCTORS[0].consultationFee);
  const [reason, setReason] = useState('');
  const [adminNotes, setAdminNotes] = useState('');
  const [status, setStatus] = useState<'confirmed' | 'in-consultation' | 'completed'>('confirmed');

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Doctors in department
  const departmentDoctors = useMemo(() => {
    return DOCTORS.filter(d => d.departmentId === selectedDeptId);
  }, [selectedDeptId]);

  // Update selected doctor when department changes
  const handleDepartmentChange = (deptId: string) => {
    setSelectedDeptId(deptId);
    const docs = DOCTORS.filter(d => d.departmentId === deptId);
    if (docs.length > 0) {
      setSelectedDocId(docs[0].id);
      setFee(docs[0].consultationFee);
    }
  };

  const handleDoctorChange = (docId: string) => {
    setSelectedDocId(docId);
    const doc = DOCTORS.find(d => d.id === docId);
    if (doc) {
      setFee(doc.consultationFee);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!patientName.trim()) newErrors.name = 'Patient name is required';
    if (!patientPhone.trim()) newErrors.phone = 'Contact phone is required';
    if (!bookingDate) newErrors.date = 'Date is required';
    if (!reason.trim()) newErrors.reason = 'Clinical reason / symptom required';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const doc = DOCTORS.find(d => d.id === selectedDocId) || DOCTORS[0];
    const dept = DEPARTMENTS.find(d => d.id === selectedDeptId) || DEPARTMENTS[0];
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const referenceCode = `WCH-ADM-${randomSuffix}`;

    const newAppointment: Appointment = {
      id: `apt-adm-${Date.now()}`,
      referenceCode,
      doctorId: doc.id,
      doctorName: doc.name,
      doctorTitle: doc.title,
      departmentId: dept.id,
      departmentName: dept.name,
      patientName: patientName.trim(),
      patientEmail: patientEmail.trim() || `${patientName.toLowerCase().replace(/\s+/g, '.')}@patient.wecare.org`,
      patientPhone: patientPhone.trim(),
      patientAge: parseInt(patientAge, 10) || 30,
      patientGender,
      isExistingPatient,
      date: bookingDate,
      timeSlot,
      consultationType,
      reason: reason.trim(),
      notes: adminNotes.trim() ? `[Admin Desk]: ${adminNotes.trim()}` : undefined,
      status,
      createdAt: new Date().toISOString(),
      consultationFee: Number(fee) || doc.consultationFee,
      roomNumber: consultationType === 'in-person' ? roomNumber : 'Telehealth Video Suite'
    };

    onSaveBooking(newAppointment);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden my-auto animate-in fade-in duration-150">
        
        {/* Header */}
        <div className="px-6 py-4.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white">
              <Building2 className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-white">
                Admin Desk: New Patient Booking
              </h3>
              <p className="text-xs text-slate-400">
                Direct hospital scheduling & admission management
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 max-h-[78vh] overflow-y-auto space-y-5">
          {/* Section 1: Patient Information */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
              <User className="w-4 h-4 text-teal-600" />
              Patient Identification
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Patient Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Robert Williams"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                />
                {errors.name && <p className="text-2xs text-rose-600 mt-1">{errors.name}</p>}
              </div>

              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Mobile Phone Number *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="+1 (555) 345-6789"
                  value={patientPhone}
                  onChange={(e) => setPatientPhone(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                />
                {errors.phone && <p className="text-2xs text-rose-600 mt-1">{errors.phone}</p>}
              </div>

              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="patient@example.com"
                  value={patientEmail}
                  onChange={(e) => setPatientEmail(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                    Age
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="120"
                    value={patientAge}
                    onChange={(e) => setPatientAge(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                    Gender
                  </label>
                  <select
                    value={patientGender}
                    onChange={(e) => setPatientGender(e.target.value as any)}
                    className="w-full px-2 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                  >
                    <option value="female">Female</option>
                    <option value="male">Male</option>
                    <option value="other">Other</option>
                    <option value="prefer-not-to-say">Unspecified</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-2.5 flex items-center gap-2">
              <input
                type="checkbox"
                id="adminExistingPatient"
                checked={isExistingPatient}
                onChange={(e) => setIsExistingPatient(e.target.checked)}
                className="rounded text-teal-600 focus:ring-teal-500 h-3.5 w-3.5"
              />
              <label htmlFor="adminExistingPatient" className="text-2xs text-slate-600 cursor-pointer">
                Existing registered hospital patient with medical record folder on file
              </label>
            </div>
          </div>

          {/* Section 2: Clinical Department & Specialist */}
          <div className="pt-3 border-t border-slate-200">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
              <Stethoscope className="w-4 h-4 text-teal-600" />
              Clinical Department & Specialist
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Department
                </label>
                <select
                  value={selectedDeptId}
                  onChange={(e) => handleDepartmentChange(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                >
                  {DEPARTMENTS.map((dept) => (
                    <option key={dept.id} value={dept.id}>
                      {dept.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Attending Specialist ({departmentDoctors.length} Available)
                </label>
                <select
                  value={selectedDocId}
                  onChange={(e) => handleDoctorChange(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                >
                  {departmentDoctors.map((doc) => (
                    <option key={doc.id} value={doc.id}>
                      {doc.name} · ${doc.consultationFee} ({doc.title.split('&')[0]})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Date, Time & Location */}
          <div className="pt-3 border-t border-slate-200">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-teal-600" />
              Appointment Schedule & Facility
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Appointment Date *
                </label>
                <input
                  type="date"
                  required
                  value={bookingDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setBookingDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                />
              </div>

              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Time Slot
                </label>
                <select
                  value={timeSlot}
                  onChange={(e) => setTimeSlot(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                >
                  <option value="08:30 AM">08:30 AM</option>
                  <option value="09:00 AM">09:00 AM</option>
                  <option value="09:30 AM">09:30 AM</option>
                  <option value="10:00 AM">10:00 AM</option>
                  <option value="10:30 AM">10:30 AM</option>
                  <option value="11:00 AM">11:00 AM</option>
                  <option value="11:30 AM">11:30 AM</option>
                  <option value="01:30 PM">01:30 PM</option>
                  <option value="02:00 PM">02:00 PM</option>
                  <option value="02:30 PM">02:30 PM</option>
                  <option value="03:00 PM">03:00 PM</option>
                  <option value="03:30 PM">03:30 PM</option>
                  <option value="04:00 PM">04:00 PM</option>
                  <option value="04:30 PM">04:30 PM</option>
                </select>
              </div>

              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Mode
                </label>
                <select
                  value={consultationType}
                  onChange={(e) => setConsultationType(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                >
                  <option value="in-person">In-Person Outpatient</option>
                  <option value="telehealth">Video Telehealth</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
              {consultationType === 'in-person' && (
                <div className="sm:col-span-2">
                  <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                    Room / Clinic Suite
                  </label>
                  <input
                    type="text"
                    value={roomNumber}
                    onChange={(e) => setRoomNumber(e.target.value)}
                    placeholder="e.g. Suite 304, Cardio Pavilion"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                  />
                </div>
              )}

              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Consultation Fee ($)
                </label>
                <input
                  type="number"
                  min="0"
                  value={fee}
                  onChange={(e) => setFee(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600 font-mono"
                />
              </div>

              <div>
                <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                  Initial Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600 font-semibold"
                >
                  <option value="confirmed">Confirmed (Scheduled)</option>
                  <option value="in-consultation">In Consultation (Arrived)</option>
                  <option value="completed">Completed</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 4: Clinical Reason & Admin Notes */}
          <div className="pt-3 border-t border-slate-200">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Reason for Visit & Desk Notes
            </h4>
            <div className="space-y-2.5">
              <div>
                <input
                  type="text"
                  required
                  placeholder="Primary complaint (e.g. Post-surgery follow-up check / Knee stiffness assessment)"
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                />
                {errors.reason && <p className="text-2xs text-rose-600 mt-1">{errors.reason}</p>}
              </div>

              <div>
                <textarea
                  rows={2}
                  placeholder="Internal Admin / Reception notes (e.g. Subsidized insurance verified; requested wheelchair assistance)"
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
                />
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Create Official Booking</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
