import React from 'react';
import { Doctor } from '../types/hospital';
import { Calendar, Video, Star, Award, Stethoscope, ChevronRight } from 'lucide-react';

interface DoctorCardProps {
  doctor: Doctor;
  onBookAppointment: (doctorId: string, departmentId: string) => void;
  onViewDoctorProfile: (doctor: Doctor) => void;
}

export const DoctorCard: React.FC<DoctorCardProps> = ({
  doctor,
  onBookAppointment,
  onViewDoctorProfile
}) => {
  // Generate consistent initials
  const initials = doctor.name
    .split(' ')
    .filter(n => !n.startsWith('Dr.'))
    .slice(0, 2)
    .map(n => n[0])
    .join('');

  return (
    <div className="bg-white rounded-xl border border-slate-200/90 hover:border-teal-500/60 p-5 flex flex-col justify-between transition-all duration-150 hover:shadow-sm group">
      <div>
        {/* Doctor Header */}
        <div className="flex items-start gap-3.5 mb-3.5">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-teal-50 to-slate-100 border border-slate-200 flex items-center justify-center text-teal-800 font-extrabold text-lg shrink-0 shadow-2xs">
            {initials || 'MD'}
          </div>

          <div className="min-w-0 flex-1">
            <h3 
              onClick={() => onViewDoctorProfile(doctor)}
              className="text-base font-bold text-slate-900 truncate hover:text-teal-700 cursor-pointer transition-colors"
            >
              {doctor.name}
            </h3>
            <p className="text-xs text-slate-500 line-clamp-1">{doctor.title}</p>
            
            {/* Unboxed metadata with typographic separators - zero-pill discipline */}
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
              <span className="font-semibold text-slate-700">{doctor.experienceYears} yrs experience</span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1 text-amber-700 font-medium">
                <Star className="w-3 h-3 fill-amber-400 text-amber-500 inline" />
                {doctor.rating.toFixed(1)} ({doctor.reviewCount})
              </span>
            </div>
          </div>
        </div>

        {/* Department & Qualification */}
        <div className="text-xs space-y-1 py-2 border-t border-slate-100">
          <p className="text-slate-600">
            <span className="text-slate-400">Department:</span> {doctor.departmentName}
          </p>
          <p className="text-slate-600 truncate">
            <span className="text-slate-400">Credentials:</span> {doctor.qualification}
          </p>
        </div>

        {/* Specializations list */}
        <div className="mt-2.5">
          <p className="text-2xs uppercase tracking-wider text-slate-400 font-semibold mb-1">
            Clinical Focus
          </p>
          <div className="text-xs text-slate-600 line-clamp-2">
            {doctor.specializations.join(' · ')}
          </div>
        </div>

        {/* Consultation Types & Languages */}
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            {doctor.telehealthAvailable && (
              <span className="flex items-center gap-1 text-teal-700">
                <Video className="w-3.5 h-3.5" />
                <span>Telehealth</span>
              </span>
            )}
            {doctor.telehealthAvailable && <span aria-hidden="true">·</span>}
            <span>In-Person</span>
          </div>
          <div className="font-bold text-slate-900 text-sm">
            ${doctor.consultationFee}
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => onViewDoctorProfile(doctor)}
          className="w-full py-2 px-3 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200 cursor-pointer text-center"
        >
          View Profile
        </button>
        <button
          type="button"
          onClick={() => onBookAppointment(doctor.id, doctor.departmentId)}
          className="w-full py-2 px-3 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg transition-colors cursor-pointer text-center shadow-xs"
        >
          Book Visit
        </button>
      </div>
    </div>
  );
};
