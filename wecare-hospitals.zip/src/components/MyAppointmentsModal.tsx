import React, { useState } from 'react';
import { Appointment } from '../types/hospital';
import { 
  X, Calendar, Clock, MapPin, AlertCircle, CheckCircle2, 
  Trash2, RefreshCw, Printer, User, Building2, Stethoscope, Video, LogIn, ShieldCheck
} from 'lucide-react';
import { HOSPITAL_INFO } from '../data/hospitalData';
import { useAuth } from '../context/AuthContext';

interface MyAppointmentsModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointments: Appointment[];
  onCancelAppointment: (id: string) => void;
  onRescheduleAppointment: (id: string, newDate: string, newSlot: string) => void;
  onOpenBooking: () => void;
  onOpenAuth: (text?: string) => void;
}

export const MyAppointmentsModal: React.FC<MyAppointmentsModalProps> = ({
  isOpen,
  onClose,
  appointments,
  onCancelAppointment,
  onRescheduleAppointment,
  onOpenBooking,
  onOpenAuth
}) => {
  const { currentUser, userProfile } = useAuth();
  const [activeFilter, setActiveFilter] = useState<'all' | 'confirmed' | 'cancelled'>('all');
  const [reschedulingId, setReschedulingId] = useState<string | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState<string>('');
  const [rescheduleSlot, setRescheduleSlot] = useState<string>('10:00 AM');
  const [confirmCancelId, setConfirmCancelId] = useState<string | null>(null);

  if (!isOpen) return null;

  const filteredAppointments = appointments.filter(apt => {
    if (activeFilter === 'confirmed') return apt.status === 'confirmed' || apt.status === 'rescheduled';
    if (activeFilter === 'cancelled') return apt.status === 'cancelled';
    return true;
  });

  const handlePrintSlip = (apt: Appointment) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Appointment Slip - ${apt.referenceCode}</title>
          <style>
            body { font-family: 'Segoe UI', system-ui, sans-serif; padding: 40px; color: #1e293b; }
            .header { border-bottom: 2px solid #0d9488; padding-bottom: 15px; margin-bottom: 20px; }
            .title { font-size: 24px; font-weight: bold; color: #0f172a; margin: 0; }
            .sub { color: #64748b; font-size: 14px; margin-top: 4px; }
            .badge { display: inline-block; background: #f0fdfa; color: #0d9488; font-weight: bold; padding: 4px 12px; border-radius: 4px; font-size: 14px; margin: 15px 0; }
            .table { width: 100%; border-collapse: collapse; margin-top: 15px; }
            .table td { padding: 10px 0; border-bottom: 1px solid #e2e8f0; font-size: 14px; }
            .label { color: #64748b; width: 35%; font-weight: 600; }
            .value { color: #0f172a; font-weight: bold; }
            .footer { margin-top: 40px; font-size: 12px; color: #94a3b8; border-top: 1px solid #cbd5e1; padding-top: 15px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1 class="title">${HOSPITAL_INFO.name}</h1>
            <p class="sub">${HOSPITAL_INFO.address} · Emergency: ${HOSPITAL_INFO.emergencyPhone}</p>
          </div>
          <div class="badge">CONFIRMED OUTPATIENT CONSULTATION PASS</div>
          <table class="table">
            <tr><td class="label">Reference ID</td><td class="value">${apt.referenceCode}</td></tr>
            <tr><td class="label">Consulting Specialist</td><td class="value">${apt.doctorName} (${apt.departmentName})</td></tr>
            <tr><td class="label">Patient Name</td><td class="value">${apt.patientName} (${apt.patientGender}, Age: ${apt.patientAge})</td></tr>
            <tr><td class="label">Date & Time</td><td class="value">${apt.date} at ${apt.timeSlot}</td></tr>
            <tr><td class="label">Mode & Room</td><td class="value">${apt.consultationType.toUpperCase()} - ${apt.roomNumber || 'Video Consultation'}</td></tr>
            <tr><td class="label">Contact Phone</td><td class="value">${apt.patientPhone}</td></tr>
            <tr><td class="label">Clinical Reason</td><td class="value">${apt.reason}</td></tr>
            <tr><td class="label">Consultation Fee</td><td class="value">$${apt.consultationFee} (To be paid at reception desk or verified insurance)</td></tr>
          </table>
          <div class="footer">
            <p>Please present this digital slip at Outpatient Reception 15 minutes prior to appointment time. Photo ID is mandatory.</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  const handleApplyReschedule = (id: string) => {
    if (!rescheduleDate) return;
    onRescheduleAppointment(id, rescheduleDate, rescheduleSlot);
    setReschedulingId(null);
    setRescheduleDate('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden my-auto animate-in fade-in duration-150">
        
        {/* Header */}
        <div className="px-6 py-4.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
              <Calendar className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-white">
                My Bookings & Clinical Schedule
              </h3>
              <p className="text-xs text-slate-400">
                Track, reschedule, or generate digital passes for your upcoming hospital appointments
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Patient Auth Bar */}
        {currentUser ? (
          <div className="px-6 py-2.5 bg-teal-50/70 border-b border-teal-100 flex items-center justify-between text-xs text-teal-900">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
              <span>
                Medical Portal: <strong>{userProfile?.displayName || currentUser.displayName || currentUser.email}</strong> ({currentUser.email})
              </span>
            </div>
            <span className="text-2xs text-teal-700 font-medium">Cloud Synchronized</span>
          </div>
        ) : (
          <div className="px-6 py-2.5 bg-amber-50/80 border-b border-amber-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-amber-900">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Sign in with your patient account to sync and manage your appointments from any device.</span>
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenAuth('Sign in to view your patient portal records');
              }}
              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-semibold text-2xs self-start sm:self-auto cursor-pointer"
            >
              Sign In Now
            </button>
          </div>
        )}

        {/* Filter bar */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-1.5 p-1 bg-slate-200/70 rounded-lg text-xs font-medium">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1 rounded-md transition-colors ${
                activeFilter === 'all' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Records ({appointments.length})
            </button>
            <button
              onClick={() => setActiveFilter('confirmed')}
              className={`px-3 py-1 rounded-md transition-colors ${
                activeFilter === 'confirmed' ? 'bg-white text-teal-800 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Active / Confirmed ({appointments.filter(a => a.status !== 'cancelled').length})
            </button>
            <button
              onClick={() => setActiveFilter('cancelled')}
              className={`px-3 py-1 rounded-md transition-colors ${
                activeFilter === 'cancelled' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Cancelled ({appointments.filter(a => a.status === 'cancelled').length})
            </button>
          </div>

          <button
            onClick={() => {
              onClose();
              onOpenBooking();
            }}
            className="text-xs font-semibold text-teal-700 hover:text-teal-900 flex items-center gap-1 cursor-pointer"
          >
            + Book New Appointment
          </button>
        </div>

        {/* Appointments List */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-4">
          {filteredAppointments.length === 0 ? (
            <div className="text-center py-12 px-4">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400 mb-3">
                <Calendar className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-800">No appointments found in this view</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-4">
                Schedule a consultation with our experienced physicians across 8 specialized clinical departments.
              </p>
              <button
                onClick={() => {
                  onClose();
                  onOpenBooking();
                }}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg transition-colors cursor-pointer"
              >
                Book An Appointment
              </button>
            </div>
          ) : (
            filteredAppointments.map((apt) => {
              const isCancelled = apt.status === 'cancelled';
              const isRescheduled = apt.status === 'rescheduled';
              const isReschedulingThis = reschedulingId === apt.id;
              const isConfirmingCancelThis = confirmCancelId === apt.id;

              return (
                <div
                  key={apt.id}
                  className={`p-4 rounded-xl border transition-all ${
                    isCancelled
                      ? 'bg-slate-50/70 border-slate-200 opacity-75'
                      : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded border border-teal-100">
                        {apt.referenceCode}
                      </span>
                      <span className="text-xs text-slate-400">·</span>
                      <span className="text-xs text-slate-500">
                        Booked on {new Date(apt.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      {isCancelled && (
                        <span className="text-2xs font-bold px-2 py-0.5 rounded bg-rose-50 text-rose-700 border border-rose-200">
                          Cancelled
                        </span>
                      )}
                      {isRescheduled && (
                        <span className="text-2xs font-bold px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                          Rescheduled
                        </span>
                      )}
                      {!isCancelled && !isRescheduled && (
                        <span className="text-2xs font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                          Confirmed
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 text-xs">
                    <div>
                      <p className="text-slate-400 font-medium">Doctor & Department</p>
                      <p className="text-sm font-bold text-slate-900 mt-0.5">{apt.doctorName}</p>
                      <p className="text-slate-500">{apt.departmentName}</p>
                    </div>

                    <div>
                      <p className="text-slate-400 font-medium">Date & Time</p>
                      <p className="text-sm font-bold text-slate-900 mt-0.5">{apt.date}</p>
                      <p className="text-teal-700 font-semibold">{apt.timeSlot}</p>
                    </div>

                    <div>
                      <p className="text-slate-400 font-medium">Patient Details</p>
                      <p className="text-sm font-bold text-slate-900 mt-0.5">{apt.patientName}</p>
                      <p className="text-slate-500 capitalize">{apt.consultationType} · ${apt.consultationFee}</p>
                    </div>
                  </div>

                  {apt.reason && (
                    <div className="mt-3 pt-2 text-xs text-slate-600 bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                      <span className="font-semibold text-slate-700">Reason:</span> {apt.reason}
                    </div>
                  )}

                  {/* Reschedule inline editor */}
                  {isReschedulingThis && (
                    <div className="mt-3 p-3 bg-amber-50/70 border border-amber-200 rounded-lg space-y-2 animate-in fade-in duration-100">
                      <p className="text-xs font-bold text-amber-900">Select New Date & Time Slot:</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <input
                          type="date"
                          value={rescheduleDate}
                          min={new Date().toISOString().split('T')[0]}
                          onChange={(e) => setRescheduleDate(e.target.value)}
                          className="px-2.5 py-1.5 bg-white border border-amber-300 rounded text-xs text-slate-800"
                        />
                        <select
                          value={rescheduleSlot}
                          onChange={(e) => setRescheduleSlot(e.target.value)}
                          className="px-2.5 py-1.5 bg-white border border-amber-300 rounded text-xs text-slate-800"
                        >
                          <option value="09:00 AM">09:00 AM</option>
                          <option value="10:00 AM">10:00 AM</option>
                          <option value="11:30 AM">11:30 AM</option>
                          <option value="02:00 PM">02:00 PM</option>
                          <option value="03:30 PM">03:30 PM</option>
                          <option value="04:30 PM">04:30 PM</option>
                        </select>
                      </div>
                      <div className="flex items-center justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setReschedulingId(null)}
                          className="px-2.5 py-1 text-xs text-slate-600 hover:text-slate-900"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          disabled={!rescheduleDate}
                          onClick={() => handleApplyReschedule(apt.id)}
                          className="px-3 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded text-xs font-semibold disabled:opacity-50"
                        >
                          Save New Slot
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Cancel Confirmation inline box */}
                  {isConfirmingCancelThis && (
                    <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs space-y-2">
                      <p className="font-semibold text-rose-900">
                        Are you sure you want to cancel this appointment with {apt.doctorName}?
                      </p>
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setConfirmCancelId(null)}
                          className="px-2.5 py-1 text-slate-600 hover:text-slate-900"
                        >
                          Keep Appointment
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onCancelAppointment(apt.id);
                            setConfirmCancelId(null);
                          }}
                          className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded font-semibold"
                        >
                          Yes, Cancel Appointment
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Bottom Action Affordances */}
                  {!isCancelled && !isReschedulingThis && !isConfirmingCancelThis && (
                    <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                      <button
                        type="button"
                        onClick={() => handlePrintSlip(apt)}
                        className="text-slate-600 hover:text-slate-900 flex items-center gap-1 font-medium cursor-pointer"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Print Digital Pass</span>
                      </button>

                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => {
                            setReschedulingId(apt.id);
                            setRescheduleDate(apt.date);
                            setRescheduleSlot(apt.timeSlot);
                          }}
                          className="text-amber-700 hover:text-amber-800 font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <RefreshCw className="w-3 h-3" />
                          <span>Reschedule</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setConfirmCancelId(apt.id)}
                          className="text-rose-600 hover:text-rose-700 font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Cancel</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>Need help with medical records? Call Desk: {HOSPITAL_INFO.generalPhone}</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-900 transition-colors font-semibold"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
