import React, { useState } from 'react';
import { PageId } from '../types/hospital';
import { Phone, Calendar, Menu, X, HeartPulse, ShieldAlert, ShieldCheck, User, LogOut, LogIn } from 'lucide-react';
import { HOSPITAL_INFO } from '../data/hospitalData';
import { useAuth } from '../context/AuthContext';

interface NavbarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  onOpenBooking: (doctorId?: string, departmentId?: string) => void;
  onOpenAppointments: () => void;
  onOpenAuth: () => void;
  appointmentCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentPage,
  onNavigate,
  onOpenBooking,
  onOpenAppointments,
  onOpenAuth,
  appointmentCount
}) => {
  const { currentUser, userProfile, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const handleNavClick = (page: PageId) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const displayName = userProfile?.displayName || currentUser?.displayName || currentUser?.email?.split('@')[0] || 'Patient';
  const userInitials = displayName
    .split(' ')
    .slice(0, 2)
    .map((n: string) => n[0])
    .join('')
    .toUpperCase();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Emergency & Quick Info Bar */}
      <div className="bg-slate-900 text-slate-300 text-xs py-1.5 px-4 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5 text-rose-400 font-medium">
              <ShieldAlert className="w-3.5 h-3.5" />
              24/7 Level 1 Trauma Emergency:
            </span>
            <a 
              href={`tel:${HOSPITAL_INFO.emergencyPhone.replace(/[^0-9+]/g, '')}`} 
              className="text-white font-semibold hover:text-teal-300 transition-colors"
            >
              {HOSPITAL_INFO.emergencyPhone}
            </a>
          </div>
          <div className="hidden md:flex items-center gap-4 text-slate-400">
            <span>{HOSPITAL_INFO.address.split(',')[0]}</span>
            <span aria-hidden="true">·</span>
            <span>JCI Gold Seal Accredited</span>
          </div>
        </div>
      </div>

      {/* Main 3-Zone Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 h-18 flex items-center justify-between gap-4">
        {/* Zone 1: Single element Brand Wordmark */}
        <button
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-2.5 text-left group focus-visible:outline-teal-600 rounded-md"
        >
          <div className="w-9 h-9 rounded-lg bg-teal-600 flex items-center justify-center text-white shadow-sm shadow-teal-600/30 group-hover:bg-teal-700 transition-colors">
            <HeartPulse className="w-5 h-5" />
          </div>
          <span className="text-xl font-extrabold tracking-tight text-slate-900 font-display">
            WeCare <span className="text-teal-600 font-bold">Hospitals</span>
          </span>
        </button>

        {/* Zone 2: Navigation Links (single line text links) */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-600">
          <button
            onClick={() => handleNavClick('home')}
            className={`transition-colors hover:text-slate-900 pb-0.5 ${
              currentPage === 'home'
                ? 'text-teal-600 font-semibold border-b-2 border-teal-600'
                : ''
            }`}
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className={`transition-colors hover:text-slate-900 pb-0.5 ${
              currentPage === 'about'
                ? 'text-teal-600 font-semibold border-b-2 border-teal-600'
                : ''
            }`}
          >
            About
          </button>
          <button
            onClick={() => handleNavClick('departments')}
            className={`transition-colors hover:text-slate-900 pb-0.5 ${
              currentPage === 'departments'
                ? 'text-teal-600 font-semibold border-b-2 border-teal-600'
                : ''
            }`}
          >
            Departments
          </button>
          <button
            onClick={() => handleNavClick('doctors')}
            className={`transition-colors hover:text-slate-900 pb-0.5 ${
              currentPage === 'doctors'
                ? 'text-teal-600 font-semibold border-b-2 border-teal-600'
                : ''
            }`}
          >
            Doctors
          </button>
          <button
            onClick={onOpenAppointments}
            className="flex items-center gap-1.5 transition-colors hover:text-slate-900 text-slate-600"
          >
            <Calendar className="w-4 h-4 text-slate-500" />
            <span>My Bookings</span>
            {appointmentCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-teal-100 text-teal-800 text-xs font-semibold flex items-center justify-center">
                {appointmentCount}
              </span>
            )}
          </button>
          <button
            onClick={() => handleNavClick('admin')}
            className={`flex items-center gap-1.5 transition-colors hover:text-slate-900 pb-0.5 ${
              currentPage === 'admin'
                ? 'text-teal-600 font-semibold border-b-2 border-teal-600'
                : 'text-slate-600'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-teal-600" />
            <span>Admin Portal</span>
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-3">
          {currentUser ? (
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 transition-colors text-left cursor-pointer focus-visible:outline-teal-600"
              >
                <div className="w-8 h-8 rounded-full bg-teal-100 text-teal-800 font-bold text-xs flex items-center justify-center border border-teal-200">
                  {userInitials || 'P'}
                </div>
                <div className="hidden sm:block text-xs">
                  <p className="font-bold text-slate-800 leading-tight truncate max-w-[120px]">{displayName}</p>
                  <p className="text-2xs text-slate-400">Patient</p>
                </div>
              </button>

              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-100">
                  <div className="px-4 py-2 border-b border-slate-100 text-xs">
                    <p className="font-bold text-slate-900 truncate">{displayName}</p>
                    <p className="text-slate-400 truncate text-2xs">{currentUser.email}</p>
                  </div>
                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      onOpenAppointments();
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                  >
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>My Bookings ({appointmentCount})</span>
                  </button>
                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      handleNavClick('admin');
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-teal-700 hover:bg-teal-50 flex items-center gap-2"
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-teal-600" />
                    <span>Hospital Admin Portal</span>
                  </button>
                  <button
                    onClick={() => {
                      setUserDropdownOpen(false);
                      logout();
                    }}
                    className="w-full text-left px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 border-t border-slate-100 mt-1"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-3.5 py-2 text-xs font-semibold text-slate-700 hover:text-teal-700 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <LogIn className="w-4 h-4 text-teal-600" />
              <span>Sign In</span>
            </button>
          )}

          <button
            onClick={() => onOpenBooking()}
            className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-700 transition-colors shadow-xs whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Book Visit</span>
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 focus-visible:outline-teal-600"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6 text-slate-800" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-2 animate-in fade-in slide-in-from-top-2 duration-150">
          {currentUser && (
            <div className="p-3 bg-teal-50/60 rounded-lg border border-teal-100 flex items-center justify-between text-xs mb-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-teal-600 text-white font-bold text-xs flex items-center justify-center">
                  {userInitials || 'P'}
                </div>
                <div>
                  <p className="font-bold text-slate-900">{displayName}</p>
                  <p className="text-2xs text-slate-500">{currentUser.email}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  logout();
                }}
                className="text-xs text-rose-600 font-semibold hover:underline"
              >
                Sign Out
              </button>
            </div>
          )}

          <button
            onClick={() => handleNavClick('home')}
            className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
              currentPage === 'home' ? 'bg-teal-50 text-teal-700' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
              currentPage === 'about' ? 'bg-teal-50 text-teal-700' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            About
          </button>
          <button
            onClick={() => handleNavClick('departments')}
            className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
              currentPage === 'departments' ? 'bg-teal-50 text-teal-700' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            Departments
          </button>
          <button
            onClick={() => handleNavClick('doctors')}
            className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium ${
              currentPage === 'doctors' ? 'bg-teal-50 text-teal-700' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            Doctors
          </button>
          <button
            onClick={() => handleNavClick('admin')}
            className={`w-full text-left px-3 py-2 rounded-md text-sm font-medium flex items-center justify-between ${
              currentPage === 'admin' ? 'bg-teal-50 text-teal-700' : 'text-slate-700 hover:bg-slate-50'
            }`}
          >
            <span className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-teal-600" />
              Admin Portal
            </span>
            <span className="text-2xs font-semibold px-2 py-0.5 rounded bg-teal-100 text-teal-800">
              Operations
            </span>
          </button>
          <button
            onClick={() => {
              setMobileMenuOpen(false);
              onOpenAppointments();
            }}
            className="w-full text-left px-3 py-2 rounded-md text-sm font-medium text-slate-700 hover:bg-slate-50 flex items-center justify-between"
          >
            <span className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-500" />
              My Bookings
            </span>
            {appointmentCount > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 text-xs font-semibold">
                {appointmentCount}
              </span>
            )}
          </button>

          {!currentUser && (
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAuth();
              }}
              className="w-full text-left px-3 py-2.5 rounded-md text-sm font-semibold text-teal-700 bg-teal-50 hover:bg-teal-100 flex items-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              <span>Sign In / Create Patient Account</span>
            </button>
          )}

          <div className="pt-2 border-t border-slate-100">
            <a
              href={`tel:${HOSPITAL_INFO.emergencyPhone.replace(/[^0-9+]/g, '')}`}
              className="flex items-center justify-center gap-2 w-full py-2.5 text-xs font-semibold text-rose-700 bg-rose-50 rounded-lg hover:bg-rose-100"
            >
              <Phone className="w-3.5 h-3.5" />
              Call Emergency: {HOSPITAL_INFO.emergencyPhone}
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
