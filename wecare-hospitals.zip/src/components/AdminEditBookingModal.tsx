import React, { useState } from 'react';
import { Appointment, Doctor, Department } from '../types/hospital';
import { DEPARTMENTS, DOCTORS, HOSPITAL_INFO } from '../data/hospitalData';
import { 
  X, Calendar, Clock, User, Phone, Mail, Building2, 
  Stethoscope, CheckCircle2, AlertCircle, Trash2, Printer, Save, RefreshCw
} from 'lucide-react';

interface AdminEditBookingModalProps {
  booking: Appointment | null;
  isOpen: boolean;
  onClose: () => void;
  onUpdateBooking: (updated: Appointment) => void;
  onDeleteBooking: (id: string) => void;
}

export const AdminEditBookingModal: React.FC<AdminEditBookingModalProps> = ({
  booking,
  isOpen,
  onClose,
  onUpdateBooking,
  onDeleteBooking
}) => {
  if (!isOpen || !booking) return null;

  const [status, setStatus] = useState<Appointment['status']>(booking.status);
  const [date, setDate] = useState(booking.date);
  const [timeSlot, setTimeSlot] = useState(booking.timeSlot);
  const [roomNumber, setRoomNumber] = useState(booking.roomNumber || '');
  const [notes, setNotes] = useState(booking.notes || '');
  const [fee, setFee] = useState<number>(booking.consultationFee);
  const [patientPhone, setPatientPhone] = useState(booking.patientPhone);
  const [selectedDocId, setSelectedDocId] = useState(booking.doctorId);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const selectedDoctor = DOCTORS.find(d => d.id === selectedDocId) || DOCTORS[0];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: Appointment = {
      ...booking,
      status,
      date,
      timeSlot,
      roomNumber: roomNumber.trim() || undefined,
      notes: notes.trim() || undefined,
      consultationFee: Number(fee) || booking.consultationFee,
      patientPhone: patientPhone.trim(),
      doctorId: selectedDoctor.id,
      doctorName: selectedDoctor.name,
      doctorTitle: selectedDoctor.title,
      departmentId: selectedDoctor.departmentId,
      departmentName: selectedDoctor.departmentName
    };
    onUpdateBooking(updated);
    onClose();
  };

  const handlePrintDocket = () => {
    try {
      const printWindow = window.open('', '_blank');
      if (!printWindow) {
        window.print();
        return;
      }
      printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Hospital Case File - ${booking.referenceCode}</title>
          <style>
            body { font-family: 'Segoe UI', system-ui, sans-serif; padding: 40px; color: #0f172a; max-width: 800px; margin: auto; }
            .header { border-bottom: 3px solid #0d9488; padding-bottom: 20px; display: flex; justify-content: space-between; align-items: flex-start; }
            .hosp-title { font-size: 26px; font-weight: 800; color: #0f172a; margin: 0; }
            .hosp-sub { color: #64748b; font-size: 13px; margin-top: 4px; }
            .docket-badge { background: #0f172a; color: white; padding: 6px 14px; font-size: 12px; font-weight: bold; border-radius: 4px; }
            .ref-strip { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; margin: 20px 0; display: flex; justify-content: space-between; }
            .section-title { font-size: 13px; font-weight: 800; text-transform: uppercase; color: #64748b; margin-top: 25px; margin-bottom: 8px; border-bottom: 1px solid #e2e8f0; padding-bottom: 4px; }
            table { width: 100%; border-collapse: collapse; margin-top: 10px; }
            td { padding: 8px 0; font-size: 14px; border-bottom: 1px solid #f1f5f9; }
            .lbl { width: 35%; color: #64748b; font-weight: 600; }
            .val { font-weight: 700; color: #0f172a; }
            .footer { margin-top: 40px; border-top: 1px solid #cbd5e1; padding-top: 15px; font-size: 12px; color: #94a3b8; text-align: center; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <h1 class="hosp-title">${HOSPITAL_INFO.name}</h1>
              <div class="hosp-sub">${HOSPITAL_INFO.address} · Emergency: ${HOSPITAL_INFO.emergencyPhone}</div>
            </div>
            <div class="docket-badge">ADMINISTRATION ADMISSION DOCKET</div>
          </div>

          <div class="ref-strip">
            <div>
              <span style="font-size: 11px; color: #64748b; text-transform: uppercase;">Reference Code</span>
              <div style="font-size: 20px; font-weight: 800; color: #0d9488; font-family: monospace;">${booking.referenceCode}</div>
            </div>
            <div>
              <span style="font-size: 11px; color: #64748b; text-transform: uppercase;">Status</span>
              <div style="font-size: 14px; font-weight: 800; text-transform: uppercase;">${status}</div>
            </div>
            <div>
              <span style="font-size: 11px; color: #64748b; text-transform: uppercase;">Consultation Fee</span>
              <div style="font-size: 16px; font-weight: 800;">$${fee}</div>
            </div>
          </div>

          <div class="section-title">Patient Profile</div>
          <table>
            <tr><td class="lbl">Patient Full Name</td><td class="val">${booking.patientName} (${booking.patientGender}, Age: ${booking.patientAge})</td></tr>
            <tr><td class="lbl">Primary Contact Phone</td><td class="val">${patientPhone}</td></tr>
            <tr><td class="lbl">Email Address</td><td class="val">${booking.patientEmail}</td></tr>
            <tr><td class="lbl">Patient History Status</td><td class="val">${booking.isExistingPatient ? 'Existing Hospital Record File' : 'New Intake Registration'}</td></tr>
          </table>

          <div class="section-title">Clinical Allocation</div>
          <table>
            <tr><td class="lbl">Attending Specialist</td><td class="val">${selectedDoctor.name} (${selectedDoctor.title})</td></tr>
            <tr><td class="lbl">Clinical Department</td><td class="val">${selectedDoctor.departmentName}</td></tr>
            <tr><td class="lbl">Scheduled Time Slot</td><td class="val">${date} at ${timeSlot}</td></tr>
            <tr><td class="lbl">Consultation Mode & Room</td><td class="val">${booking.consultationType.toUpperCase()} - ${roomNumber || 'Scheduled Outpatient Suite'}</td></tr>
            <tr><td class="lbl">Primary Reason for Visit</td><td class="val">${booking.reason}</td></tr>
            ${notes ? `<tr><td class="lbl">Internal Desk Notes</td><td class="val">${notes}</td></tr>` : ''}
          </table>

          <div class="footer">
            Generated via WeCare Hospitals Executive Desk Management Console. Official hospital record.
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  } catch {
    window.print();
  }
};

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden my-auto animate-in fade-in duration-150">
        
        {/* Header */}
        <div className="px-6 py-4.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
              <RefreshCw className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold font-display text-white">
                  Manage Booking
                </h3>
                <span className="font-mono text-xs font-bold text-teal-300 bg-slate-800 px-2 py-0.5 rounded">
                  {booking.referenceCode}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Patient: {booking.patientName} · {booking.departmentName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-6 max-h-[78vh] overflow-y-auto space-y-4 text-xs">
          {/* Quick Status Bar */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
            <label className="block text-2xs uppercase tracking-wider font-bold text-slate-700">
              Update Clinical / Admission Status
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {(['confirmed', 'in-consultation', 'completed', 'rescheduled', 'cancelled'] as const).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatus(st)}
                  className={`py-2 px-1 text-center font-bold text-2xs uppercase tracking-wider rounded-lg border transition-all cursor-pointer ${
                    status === st
                      ? st === 'confirmed'
                        ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                        : st === 'in-consultation'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : st === 'completed'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : st === 'rescheduled'
                        ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                        : 'bg-rose-600 text-white border-rose-600 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {st.replace('-', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Schedule & Room */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                Appointment Date
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                Time Slot
              </label>
              <select
                value={timeSlot}
                onChange={(e) => setTimeSlot(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600 font-semibold"
              >
                <option value="08:30 AM">08:30 AM</option>
                <option value="09:00 AM">09:00 AM</option>
                <option value="09:30 AM">09:30 AM</option>
                <option value="10:00 AM">10:00 AM</option>
                <option value="10:30 AM">10:30 AM</option>
                <option value="11:00 AM">11:00 AM</option>
                <option value="11:30 AM">11:30 AM</option>
                <option value="01:30 PM">01:30 PM</option>
                <option value="02:00 PM">02:00 PM</option>
                <option value="02:30 PM">02:30 PM</option>
                <option value="03:00 PM">03:00 PM</option>
                <option value="03:30 PM">03:30 PM</option>
                <option value="04:00 PM">04:00 PM</option>
                <option value="04:30 PM">04:30 PM</option>
              </select>
            </div>

            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                Fee ($)
              </label>
              <input
                type="number"
                min="0"
                value={fee}
                onChange={(e) => setFee(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600 font-mono"
              />
            </div>
          </div>

          {/* Attending Doctor */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                Attending Specialist
              </label>
              <select
                value={selectedDocId}
                onChange={(e) => setSelectedDocId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
              >
                {DOCTORS.map((doc) => (
                  <option key={doc.id} value={doc.id}>
                    {doc.name} · {doc.departmentName.split('&')[0]}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                Assigned Clinic Room
              </label>
              <input
                type="text"
                placeholder="e.g. Suite 304, Cardio Pavilion"
                value={roomNumber}
                onChange={(e) => setRoomNumber(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
              />
            </div>
          </div>

          {/* Patient Details update */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                Patient Contact Phone
              </label>
              <input
                type="tel"
                value={patientPhone}
                onChange={(e) => setPatientPhone(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
              />
            </div>
            <div>
              <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
                Original Reason
              </label>
              <p className="px-3 py-2 bg-slate-100 rounded-lg text-slate-700 truncate">
                {booking.reason}
              </p>
            </div>
          </div>

          {/* Admin Internal Notes */}
          <div>
            <label className="block text-2xs uppercase tracking-wider font-semibold text-slate-600 mb-1">
              Admin & Triage Desk Internal Notes
            </label>
            <textarea
              rows={2}
              placeholder="e.g. VIP patient; past reports verified; blood samples collected at arrival."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:bg-white focus:border-teal-600"
            />
          </div>

          {/* Confirmation delete alert */}
          {confirmDelete && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 space-y-2 animate-in fade-in duration-100">
              <p className="font-bold">Permanent Deletion Confirmation</p>
              <p className="text-2xs">
                Are you sure you want to permanently remove booking <strong>{booking.referenceCode}</strong> for {booking.patientName}? This action cannot be undone.
              </p>
              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setConfirmDelete(false)}
                  className="px-2.5 py-1 text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onDeleteBooking(booking.id);
                    onClose();
                  }}
                  className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded font-bold"
                >
                  Confirm Delete
                </button>
              </div>
            </div>
          )}

          {/* Bottom Actions */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handlePrintDocket}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Official Docket</span>
              </button>

              {!confirmDelete && (
                <button
                  type="button"
                  onClick={() => setConfirmDelete(true)}
                  className="px-3 py-2 text-rose-600 hover:bg-rose-50 rounded-lg font-semibold flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-semibold flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Changes</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
