import React from 'react';
import { PageId } from '../types/hospital';
import { HOSPITAL_INFO, DEPARTMENTS } from '../data/hospitalData';
import { HeartPulse, Phone, Mail, MapPin, Clock, ShieldCheck, ExternalLink } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: PageId) => void;
  onOpenBooking: () => void;
  onOpenAppointments: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenBooking, onOpenAppointments }) => {
  return (
    <footer className="bg-slate-950 text-slate-400 text-sm border-t border-slate-900">
      {/* Top Banner / Call to Action Strip */}
      <div className="border-b border-slate-900 bg-slate-900/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h4 className="text-lg font-bold text-white font-display">Need Immediate Clinical Assistance?</h4>
            <p className="text-slate-400 text-sm mt-1">
              Our 24-hour triage coordinators are on standby for admissions and emergency transfers.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href={`tel:${HOSPITAL_INFO.emergencyPhone.replace(/[^0-9+]/g, '')}`}
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg transition-colors flex items-center gap-2 text-sm shadow-sm shadow-rose-900/40"
            >
              <Phone className="w-4 h-4" />
              Emergency: {HOSPITAL_INFO.emergencyPhone}
            </a>
            <button
              onClick={onOpenBooking}
              className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg transition-colors text-sm cursor-pointer"
            >
              Schedule Consultation
            </button>
          </div>
        </div>
      </div>

      {/* Main Footer Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-14 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
        {/* Brand & Address */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white">
              <HeartPulse className="w-4.5 h-4.5" />
            </div>
            <span className="text-xl font-bold tracking-tight text-white font-display">
              WeCare <span className="text-teal-400">Hospitals</span>
            </span>
          </div>

          <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
            WeCare Hospitals is a premier quaternary medical institution dedicated to precision therapeutics, ethical patient outcomes, and clinical compassion across eight specialized institutes.
          </p>

          <div className="space-y-2 text-xs text-slate-300 pt-2">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
              <span>{HOSPITAL_INFO.address}</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Phone className="w-4 h-4 text-teal-400 shrink-0" />
              <span>Appointments: {HOSPITAL_INFO.appointmentPhone}</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-teal-400 shrink-0" />
              <span>{HOSPITAL_INFO.email}</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Clock className="w-4 h-4 text-teal-400 shrink-0" />
              <span>{HOSPITAL_INFO.openingHours}</span>
            </div>
          </div>
        </div>

        {/* Navigation Links */}
        <div>
          <h5 className="text-xs font-semibold text-white uppercase tracking-wider mb-4">
            Navigation
          </h5>
          <ul className="space-y-2.5 text-sm">
            <li>
              <button
                onClick={() => { onNavigate('home'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-white transition-colors"
              >
                Hospital Home
              </button>
            </li>
            <li>
              <button
                onClick={() => { onNavigate('about'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-white transition-colors"
              >
                About WeCare
              </button>
            </li>
            <li>
              <button
                onClick={() => { onNavigate('departments'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-white transition-colors"
              >
                Clinical Departments
              </button>
            </li>
            <li>
              <button
                onClick={() => { onNavigate('doctors'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-white transition-colors"
              >
                Find a Doctor
              </button>
            </li>
            <li>
              <button
                onClick={onOpenAppointments}
                className="hover:text-white transition-colors"
              >
                My Bookings & Records
              </button>
            </li>
            <li>
              <button
                onClick={() => { onNavigate('admin'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                className="hover:text-teal-400 text-teal-500 font-semibold transition-colors flex items-center gap-1.5"
              >
                <span>Hospital Admin Desk</span>
              </button>
            </li>
          </ul>
        </div>

        {/* Specialized Centers */}
        <div>
          <h5 className="text-xs font-semibold text-white uppercase tracking-wider mb-4">
            Specialized Centers
          </h5>
          <ul className="space-y-2 text-sm">
            {DEPARTMENTS.slice(0, 5).map((dept) => (
              <li key={dept.id}>
                <button
                  onClick={() => { onNavigate('departments'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="hover:text-white transition-colors text-left truncate block max-w-full"
                >
                  {dept.name.split('&')[0]}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Quality & Accreditation */}
        <div>
          <h5 className="text-xs font-semibold text-white uppercase tracking-wider mb-4">
            Accreditation & Standards
          </h5>
          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
              <div className="flex items-center gap-2 text-teal-400 font-semibold mb-1">
                <ShieldCheck className="w-4 h-4" />
                <span>JCI Gold Seal</span>
              </div>
              <p className="text-slate-400 text-xs">
                Accredited for patient safety, clinical protocols, and surgical standards.
              </p>
            </div>
            <div className="text-slate-400 space-y-1">
              <p>• NABH Digital Health Hospital</p>
              <p>• CAP Certified Central Labs</p>
              <p>• Level 1 Trauma Center Protocol</p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar: Copyright and Legal */}
      <div className="border-t border-slate-900 bg-slate-950 py-6 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} WeCare Hospitals. All medical services administered under licensed healthcare regulations.
          </div>
          <div className="flex items-center gap-6">
            <span className="hover:text-slate-400 cursor-pointer">Patient Bill of Rights</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-slate-400 cursor-pointer">Privacy & HIPAA Compliance</span>
            <span aria-hidden="true">·</span>
            <span className="hover:text-slate-400 cursor-pointer">Quality Reports</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
