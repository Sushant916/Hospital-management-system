import React from 'react';
import { Doctor } from '../types/hospital';
import { 
  X, Calendar, Clock, Star, Award, GraduationCap, 
  Languages, Video, Building2, Stethoscope, CheckCircle2 
} from 'lucide-react';

interface DoctorDetailModalProps {
  doctor: Doctor | null;
  onClose: () => void;
  onBookAppointment: (doctorId: string, departmentId: string) => void;
}

export const DoctorDetailModal: React.FC<DoctorDetailModalProps> = ({
  doctor,
  onClose,
  onBookAppointment
}) => {
  if (!doctor) return null;

  const initials = doctor.name
    .split(' ')
    .filter(n => !n.startsWith('Dr.'))
    .slice(0, 2)
    .map(n => n[0])
    .join('');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden my-auto animate-in fade-in duration-150">
        
        {/* Header Bar */}
        <div className="px-6 py-4.5 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-teal-400" />
            <h3 className="text-base font-bold font-display text-white">Physician Clinical Profile</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
          {/* Doctor Hero Header */}
          <div className="flex flex-col sm:flex-row items-start gap-4">
            <div className="w-20 h-20 rounded-2xl bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-800 font-extrabold text-2xl shrink-0">
              {initials}
            </div>

            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-bold font-display text-slate-900">{doctor.name}</h2>
              <p className="text-sm text-slate-600 mt-0.5">{doctor.title}</p>
              <p className="text-xs text-teal-700 font-medium mt-0.5">{doctor.departmentName}</p>
              
              {/* Unboxed metadata with typographic separators */}
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mt-2">
                <span>{doctor.experienceYears} Years Practice</span>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1 text-amber-700 font-medium">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500 inline" />
                  {doctor.rating.toFixed(1)} ({doctor.reviewCount} Verified Reviews)
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-bold text-slate-900">${doctor.consultationFee} Consultation Fee</span>
              </div>
            </div>
          </div>

          {/* Quick Schedule Strip */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block font-medium">Practicing Days</span>
              <span className="font-bold text-slate-800">{doctor.availableDays.join(', ')}</span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Daily Outpatient Hours</span>
              <span className="font-bold text-slate-800">
                {doctor.timeSlots[0]} – {doctor.timeSlots[doctor.timeSlots.length - 1]}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block font-medium">Languages Spoken</span>
              <span className="font-bold text-slate-800">{doctor.languages.join(', ')}</span>
            </div>
          </div>

          {/* Biography */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Clinical Background & Biography
            </h4>
            <p className="text-sm text-slate-700 leading-relaxed">
              {doctor.bio}
            </p>
          </div>

          {/* Specializations */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Areas of Clinical Specialization
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {doctor.specializations.map((spec, i) => (
                <div key={i} className="flex items-center gap-2 text-slate-700 p-2 rounded-lg bg-slate-50 border border-slate-100">
                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                  <span>{spec}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Education & Fellowships */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Medical Education & Fellowships
            </h4>
            <ul className="space-y-2 text-xs text-slate-700">
              {doctor.education.map((edu, i) => (
                <li key={i} className="flex items-start gap-2">
                  <GraduationCap className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span>{edu}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Awards & Honors */}
          {doctor.awards.length > 0 && (
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Honors & Board Recognitions
              </h4>
              <ul className="space-y-2 text-xs text-slate-700">
                {doctor.awards.map((award, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Award className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <span>{award}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Footer with Booking Button */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Consultation fee: <span className="font-bold text-slate-900">${doctor.consultationFee}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900"
            >
              Back
            </button>
            <button
              onClick={() => {
                onClose();
                onBookAppointment(doctor.id, doctor.departmentId);
              }}
              className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm shadow-teal-600/30 cursor-pointer"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Appointment with {doctor.name.split(' ')[0]} {doctor.name.split(' ')[1]}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
