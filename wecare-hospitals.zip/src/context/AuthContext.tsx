import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { 
  User, 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  signOut, 
  updateProfile 
} from 'firebase/auth';
import { auth, googleProvider } from '../firebase/firebase';
import { saveUserProfile, getUserProfile, UserProfileData } from '../firebase/firestoreService';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserProfileData | null;
  loading: boolean;
  signUpWithEmail: (email: string, pass: string, name: string, phone?: string) => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfileData | null>(null);
  const [loading, setLoading] = useState(true);

  // Sync profile when user changes
  const fetchProfile = async (user: User | null) => {
    if (!user) {
      setUserProfile(null);
      return;
    }
    try {
      let profile = await getUserProfile(user.uid);
      if (!profile) {
        // Auto-provision user record in firestore
        await saveUserProfile(user.uid, {
          email: user.email || '',
          displayName: user.displayName || user.email?.split('@')[0] || 'Patient',
          phoneNumber: user.phoneNumber || ''
        });
        profile = await getUserProfile(user.uid);
      }
      setUserProfile(profile || {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || user.email?.split('@')[0] || 'Patient',
        phoneNumber: user.phoneNumber || '',
        createdAt: new Date().toISOString(),
        role: 'patient'
      });
    } catch (err) {
      console.warn('Could not load user profile from firestore, using fallback:', err);
      setUserProfile({
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || user.email?.split('@')[0] || 'Patient',
        phoneNumber: user.phoneNumber || '',
        createdAt: new Date().toISOString(),
        role: 'patient'
      });
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        await fetchProfile(user);
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const signUpWithEmail = async (email: string, pass: string, name: string, phone?: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    if (name.trim()) {
      await updateProfile(cred.user, { displayName: name.trim() });
    }
    await saveUserProfile(cred.user.uid, {
      email,
      displayName: name.trim() || 'Patient',
      phoneNumber: phone || ''
    });
    await fetchProfile(cred.user);
  };

  const signInWithEmail = async (email: string, pass: string) => {
    const cred = await signInWithEmailAndPassword(auth, email, pass);
    await fetchProfile(cred.user);
  };

  const signInWithGoogle = async () => {
    const cred = await signInWithPopup(auth, googleProvider);
    await saveUserProfile(cred.user.uid, {
      email: cred.user.email || '',
      displayName: cred.user.displayName || 'Patient',
      phoneNumber: cred.user.phoneNumber || ''
    });
    await fetchProfile(cred.user);
  };

  const logout = async () => {
    await signOut(auth);
    setUserProfile(null);
  };

  const refreshProfile = async () => {
    if (currentUser) {
      await fetchProfile(currentUser);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        signUpWithEmail,
        signInWithEmail,
        signInWithGoogle,
        logout,
        refreshProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
