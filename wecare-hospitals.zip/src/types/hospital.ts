export interface Department {
  id: string;
  name: string;
  tagline: string;
  shortDescription: string;
  fullDescription: string;
  headDoctorId: string;
  headDoctorName: string;
  bedCount: number;
  phone: string;
  floor: string;
  treatments: string[];
  conditions: string[];
  technologies: string[];
  emergencyAvailable: boolean;
}

export interface Doctor {
  id: string;
  name: string;
  title: string;
  departmentId: string;
  departmentName: string;
  qualification: string;
  experienceYears: number;
  rating: number;
  reviewCount: number;
  consultationFee: number;
  avatarUrl?: string;
  gender: 'male' | 'female';
  availableDays: string[];
  timeSlots: string[];
  languages: string[];
  bio: string;
  education: string[];
  awards: string[];
  specializations: string[];
  acceptingNewPatients: boolean;
  telehealthAvailable: boolean;
}

export interface Appointment {
  id: string;
  referenceCode: string;
  userId?: string;
  userEmail?: string;
  doctorId: string;
  doctorName: string;
  doctorTitle: string;
  departmentId: string;
  departmentName: string;
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  patientAge: number;
  patientGender: 'male' | 'female' | 'other' | 'prefer-not-to-say';
  isExistingPatient: boolean;
  date: string;
  timeSlot: string;
  consultationType: 'in-person' | 'telehealth';
  reason: string;
  notes?: string;
  status: 'confirmed' | 'rescheduled' | 'cancelled' | 'completed' | 'in-consultation';
  createdAt: string;
  consultationFee: number;
  roomNumber?: string;
}

export type PageId = 'home' | 'about' | 'departments' | 'doctors' | 'admin';
