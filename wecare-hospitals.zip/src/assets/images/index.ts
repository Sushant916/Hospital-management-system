import heroExterior from './hero_hospital_exterior_1791111363844.jpg';
import operatingTheater from './hospital_operating_theater_1791111383048.jpg';
import doctorConsultation from './doctor_consultation_1791111398376.jpg';
import hospitalFacilities from './hospital_facilities_1791111413096.jpg';

export const HOSPITAL_IMAGES = {
  heroExterior,
  operatingTheater,
  doctorConsultation,
  hospitalFacilities
};
