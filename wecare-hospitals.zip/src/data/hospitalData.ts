import { Department, Doctor, Appointment } from '../types/hospital';

export const HOSPITAL_INFO = {
  name: 'WeCare Hospitals',
  shortName: 'WeCare',
  tagline: 'Advanced Medicine, Compassionate Care',
  emergencyPhone: '+1 (800) 932-2731',
  generalPhone: '+1 (800) 932-2700',
  appointmentPhone: '+1 (800) 932-2755',
  email: 'care@wecarehospitals.org',
  address: '742 Healthcare Boulevard, Medical District, Metro City, MC 94016',
  openingHours: 'Outpatient: Mon–Sat 8:00 AM – 8:00 PM | Emergency & Trauma: 24/7/365',
  metrics: {
    beds: '450+',
    doctors: '140+',
    annualPatients: '185,000+',
    satisfactionRate: '99.4%',
    traumaLevel: 'Level 1 Trauma Center',
    surgeriesCompleted: '32,500+'
  }
};

export const DEPARTMENTS: Department[] = [
  {
    id: 'cardiology',
    name: 'Cardiology & Vascular Surgery',
    tagline: 'Precision cardiovascular care and interventional catheterization',
    shortDescription: 'Comprehensive cardiovascular diagnostics, minimally invasive angioplasty, electrophysiology, and open-heart surgeries.',
    fullDescription: 'The WeCare Heart & Vascular Institute is an internationally recognized center of excellence. Equipped with dual-source biplane catheterization laboratories, fractional flow reserve imaging, and hybrid operating suites, our multidisciplinary team treats complex coronary, valvular, and structural heart diseases with industry-leading outcomes.',
    headDoctorId: 'doc-cardio-1',
    headDoctorName: 'Dr. Arthur Sterling',
    bedCount: 64,
    phone: '+1 (800) 932-2710',
    floor: 'Wing B, Level 3',
    treatments: [
      'Coronary Angiography & Stenting',
      'TAVR (Transcatheter Aortic Valve Replacement)',
      'Cardiac Resynchronization & Pacemaker Implantation',
      'Coronary Artery Bypass Grafting (CABG)',
      'Pediatric Heart Defect Corrections',
      'Vascular Endovascular Aneurysm Repair (EVAR)'
    ],
    conditions: [
      'Coronary Artery Disease',
      'Heart Failure & Cardiomyopathy',
      'Cardiac Arrhythmias & Atrial Fibrillation',
      'Valvular Heart Disease',
      'Hypertension & Vascular Stenosis'
    ],
    technologies: ['Biplane Cath Lab', '3D Echocardiography', 'Cardiac MRI 3T', 'Optical Coherence Tomography (OCT)'],
    emergencyAvailable: true
  },
  {
    id: 'neurology',
    name: 'Neurology & Neurosurgery',
    tagline: 'Advanced brain, spine, and peripheral nervous system medicine',
    shortDescription: 'Comprehensive stroke management, robotic spine interventions, deep brain stimulation, and neuro-rehabilitation.',
    fullDescription: 'The Neurosciences Center at WeCare provides 24/7 dedicated acute stroke triage, microsurgical neuro-oncology, and computer-navigated spinal reconstructions. With a dedicated 18-bed Neuro-ICU and state-of-the-art neuro-interventional radiology, we offer rapid-response neurological interventions.',
    headDoctorId: 'doc-neuro-1',
    headDoctorName: 'Dr. Sarah Chen',
    bedCount: 48,
    phone: '+1 (800) 932-2711',
    floor: 'Wing C, Level 4',
    treatments: [
      'Endovascular Mechanical Thrombectomy',
      'Minimally Invasive Spine Microdiscectomy',
      'Awake Craniotomy for Brain Tumors',
      'Deep Brain Stimulation (DBS) for Parkinson’s',
      'Epilepsy Monitoring & Resection',
      'Comprehensive Cognitive Rehabilitation'
    ],
    conditions: [
      'Ischemic & Hemorrhagic Stroke',
      'Brain & Spinal Cord Tumors',
      'Epilepsy & Refractory Seizures',
      'Parkinson’s Disease & Tremors',
      'Multiple Sclerosis & Peripheral Neuropathy'
    ],
    technologies: ['Intraoperative Neuro-Navigation', 'Functional MRI (fMRI)', 'Continuous EEG Telemetry', 'CyberKnife Radiosurgery'],
    emergencyAvailable: true
  },
  {
    id: 'orthopedics',
    name: 'Orthopedics & Joint Replacement',
    tagline: 'Restoring mobility through robotic arthroplasty and sports medicine',
    shortDescription: 'Computer-assisted knee and hip replacements, arthroscopic shoulder repair, complex fracture trauma, and sports injury therapy.',
    fullDescription: 'Our Orthopedic & Sports Medicine Institute combines surgical precision with aggressive, evidence-backed physiotherapy. Utilizing Mako™ robotic arm-assisted joint replacements, patients experience faster discharge times, lower tissue trauma, and natural kinematics.',
    headDoctorId: 'doc-ortho-1',
    headDoctorName: 'Dr. Robert Keller',
    bedCount: 52,
    phone: '+1 (800) 932-2712',
    floor: 'Wing A, Level 2',
    treatments: [
      'Robotic Total & Partial Knee Arthroplasty',
      'Anterior Approach Hip Replacement',
      'Arthroscopic Rotator Cuff & ACL Reconstruction',
      'Pediatric Scoliosis Correction',
      'Cartilage Restoration & PRP Therapy',
      'Complex Polytrauma Reconstruction'
    ],
    conditions: [
      'Osteoarthritis of Knee & Hip',
      'Torn ACL & Meniscal Tears',
      'Shoulder Impingement & Rotator Cuff Tears',
      'Lumbar Disc Herniation & Sciatica',
      'Sports Stress Fractures'
    ],
    technologies: ['Mako™ Robotic Arm Surgical System', 'High-Definition Arthroscopy', 'Dynamic Gait Analysis Lab'],
    emergencyAvailable: true
  },
  {
    id: 'oncology',
    name: 'Oncology & Comprehensive Cancer Center',
    tagline: 'Targeted immunotherapy, precision genomics, and surgical oncology',
    shortDescription: 'Multidisciplinary tumor boards, stereotactic radiation, personalized chemotherapy suites, and compassionate survivorship programs.',
    fullDescription: 'The WeCare Comprehensive Cancer Center unites medical oncologists, surgical oncologists, radiation physicists, and genetic counselors. Every patient case is reviewed by a dedicated tumor board to formulate individualized treatment trajectories featuring targeted therapy and clinical trials.',
    headDoctorId: 'doc-onco-1',
    headDoctorName: 'Dr. Elizabeth Thorne',
    bedCount: 56,
    phone: '+1 (800) 932-2713',
    floor: 'Wing D, Level 5',
    treatments: [
      'Targeted Immunotherapy & Biologics',
      'Organ-Preserving Surgical Oncology',
      'Linear Accelerator Stereotactic Radiotherapy (SBRT)',
      'Autologous Stem Cell Transplantation',
      'Outpatient Infusion Therapy Suites',
      'Oncoplastic Breast Reconstruction'
    ],
    conditions: [
      'Breast & Gynecological Cancers',
      'Lung & Thoracic Malignancies',
      'Colorectal & Gastrointestinal Tumors',
      'Leukemia, Lymphoma & Myeloma',
      'Head, Neck & Thyroid Cancers'
    ],
    technologies: ['Next-Generation DNA Sequencing', 'Varian TrueBeam™ Linear Accelerator', 'PET-CT 64-Slice Scanner'],
    emergencyAvailable: false
  },
  {
    id: 'pediatrics',
    name: 'Pediatrics & Neonatal ICU',
    tagline: 'Gentle, specialized medicine from newborn care through adolescence',
    shortDescription: 'Level III NICU, pediatric subspecialties, child-friendly outpatient suites, and 24/7 pediatric emergency cover.',
    fullDescription: 'Designed entirely around the comfort of children and parents, our Pediatric Center blends warm, distraction-free environments with rigorous tertiary pediatric clinical protocols. Our Level III NICU provides neonatal life support for premature infants starting from 24 weeks gestational age.',
    headDoctorId: 'doc-pedia-1',
    headDoctorName: 'Dr. Sophia Martinez',
    bedCount: 40,
    phone: '+1 (800) 932-2714',
    floor: 'Wing A, Level 4',
    treatments: [
      'Level III Neonatal Intensive Care',
      'Pediatric Asthma & Allergy Management',
      'Developmental Milestones & Neurodiversity Support',
      'Pediatric Cardiology Diagnostics',
      'Childhood Immunization Programs',
      'Emergency Pediatric Resuscitation'
    ],
    conditions: [
      'Premature Birth Complications',
      'Pediatric Respiratory Distress & Croup',
      'Childhood Infectious Diseases',
      'Juvenile Diabetes & Endocrine Disorders',
      'Congenital Anomalies'
    ],
    technologies: ['High-Frequency Oscillatory Ventilators', 'LED Phototherapy Systems', 'Pediatric Video Endoscopy'],
    emergencyAvailable: true
  },
  {
    id: 'obgyn',
    name: 'Obstetrics & Gynecology (Women’s Health)',
    tagline: 'Compassionate maternal care, high-risk obstetrics, and robotic gynecology',
    shortDescription: 'LDRP birthing suites, fetal medicine ultrasound, laparoscopic hysteroscopy, and menopause wellness clinics.',
    fullDescription: 'WeCare Women’s Health Institute supports women throughout every milestone of life. Our modern labor, delivery, recovery, and postpartum (LDRP) suites prioritize maternal comfort, natural birth choices, and continuous fetal monitoring, backed by rapid surgical readiness.',
    headDoctorId: 'doc-obgyn-1',
    headDoctorName: 'Dr. Rachel Greenberg',
    bedCount: 44,
    phone: '+1 (800) 932-2715',
    floor: 'Wing B, Level 2',
    treatments: [
      'Painless Labor & Water Birth Facilities',
      'High-Risk Pregnancy & Maternal-Fetal Medicine',
      'Robotic Myomectomy & Hysterectomy',
      'Infertility Workup & Ovulation Induction',
      'Urogynecology & Pelvic Floor Reconstruction',
      'Well-Woman Annual Preventive Screenings'
    ],
    conditions: [
      'High-Risk Gestational Complications',
      'Uterine Fibroids & Endometriosis',
      'Polycystic Ovarian Syndrome (PCOS)',
      'Pelvic Organ Prolapse',
      'Cervical Dysplasia'
    ],
    technologies: ['4D Fetal Doppler Ultrasound', 'da Vinci® Surgical Robot', 'Digital Mammography with 3D Tomosynthesis'],
    emergencyAvailable: true
  },
  {
    id: 'gastroenterology',
    name: 'Gastroenterology & Hepatology',
    tagline: 'Comprehensive digestive health, therapeutic endoscopy, and liver wellness',
    shortDescription: 'Advanced colonoscopy, capsule endoscopy, ERCP for biliary stones, and specialized fatty liver treatment programs.',
    fullDescription: 'The Digestive Health Institute at WeCare features a specialized 6-room endoscopy suite with AI-assisted polyp detection. Our gastroenterologists and hepatologists manage complex inflammatory bowel conditions, cirrhosis, and gastrointestinal motility disorders.',
    headDoctorId: 'doc-gastro-1',
    headDoctorName: 'Dr. Farhan Al-Mansoor',
    bedCount: 38,
    phone: '+1 (800) 932-2716',
    floor: 'Wing C, Level 3',
    treatments: [
      'Diagnostic & Screening High-Definition Colonoscopy',
      'Therapeutic Endoscopic Retrograde Cholangiopancreatography (ERCP)',
      'Endoscopic Ultrasound (EUS) with Fine Needle Aspiration',
      'Wireless Video Capsule Endoscopy',
      'Esophageal Manometry & 24hr pH Impedance Testing',
      'Fatty Liver & FibroScan Diagnostic Profiling'
    ],
    conditions: [
      'GERD & Acid Reflux Disease',
      'Crohn’s Disease & Ulcerative Colitis',
      'Non-Alcoholic Fatty Liver Disease (NAFLD)',
      'Gallbladder & Common Bile Duct Stones',
      'Celiac Disease & Irritable Bowel Syndrome (IBS)'
    ],
    technologies: ['AI-Assisted Endoscopy CAD EYE', 'FibroScan® 630 Expert', 'SpyGlass™ Direct Visualization Cholangioscopy'],
    emergencyAvailable: true
  },
  {
    id: 'pulmonology',
    name: 'Pulmonology & Respiratory Medicine',
    tagline: 'Restoring breath through cutting-edge pulmonary diagnostics and critical care',
    shortDescription: 'Advanced bronchoscopy, comprehensive sleep apnea labs, COPD rehabilitation, and post-viral recovery clinics.',
    fullDescription: 'Our Pulmonary & Critical Care division manages acute and chronic respiratory disorders with dedicated negative-pressure airborne isolation units, comprehensive pulmonary function laboratories, and interventional bronchoscopy suites.',
    headDoctorId: 'doc-pulmo-1',
    headDoctorName: 'Dr. Jonathan Briggs',
    bedCount: 42,
    phone: '+1 (800) 932-2717',
    floor: 'Wing D, Level 3',
    treatments: [
      'Navigational Bronchoscopy & EBUS',
      'Comprehensive Pulmonary Function Testing (PFT)',
      'Polysomnography (Sleep Study Testing)',
      'Outpatient Pulmonary Rehabilitation Program',
      'Pleural Fluid Drainage & Medical Thoracoscopy',
      'Non-Invasive Mechanical Ventilation (BiPAP/CPAP Titration)'
    ],
    conditions: [
      'Severe Asthma & Bronchiectasis',
      'Chronic Obstructive Pulmonary Disease (COPD)',
      'Obstructive Sleep Apnea (OSA)',
      'Idiopathic Pulmonary Fibrosis (IPF)',
      'Pneumonia & Pulmonary Embolism'
    ],
    technologies: ['Electromagnetic Navigation Bronchoscopy', 'Body Plethysmography Suite', 'Endobronchial Ultrasound (EBUS)'],
    emergencyAvailable: true
  }
];

export const DOCTORS: Doctor[] = [
  // --- CARDIOLOGY (3 doctors) ---
  {
    id: 'doc-cardio-1',
    name: 'Dr. Arthur Sterling',
    title: 'Chief of Cardiology & Senior Interventional Cardiologist',
    departmentId: 'cardiology',
    departmentName: 'Cardiology & Vascular Surgery',
    qualification: 'MD, FACC, FSCAI (Harvard Medical School)',
    experienceYears: 24,
    rating: 4.9,
    reviewCount: 382,
    consultationFee: 180,
    gender: 'male',
    availableDays: ['Mon', 'Tue', 'Thu', 'Fri'],
    timeSlots: ['09:00 AM', '10:00 AM', '11:30 AM', '02:00 PM', '03:30 PM'],
    languages: ['English', 'German'],
    bio: 'Dr. Sterling has pioneered minimally invasive transcatheter valve interventions and complex coronary stenting for over two decades. He has published over 70 peer-reviewed papers on structural heart therapeutics.',
    education: [
      'Fellowship in Interventional Cardiology, Brigham and Women’s Hospital',
      'Residency in Internal Medicine, Massachusetts General Hospital',
      'Doctor of Medicine (MD), Harvard Medical School'
    ],
    awards: [
      'Top Cardiologist Award - National Medical Board (2024)',
      'Distinguished Clinical Investigator in Interventional Cardiology'
    ],
    specializations: ['Transcatheter Aortic Valve Replacement (TAVR)', 'Complex Angioplasty', 'Coronary Artery Disease'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-cardio-2',
    name: 'Dr. Meera Nambiar',
    title: 'Senior Consultant Cardiologist & Echocardiography Specialist',
    departmentId: 'cardiology',
    departmentName: 'Cardiology & Vascular Surgery',
    qualification: 'MD, DM Cardiology, FESC (Johns Hopkins)',
    experienceYears: 16,
    rating: 4.9,
    reviewCount: 295,
    consultationFee: 150,
    gender: 'female',
    availableDays: ['Mon', 'Wed', 'Fri', 'Sat'],
    timeSlots: ['09:30 AM', '11:00 AM', '02:30 PM', '04:00 PM'],
    languages: ['English', 'Hindi', 'Malayalam'],
    bio: 'Specializing in preventative cardiovascular medicine, advanced strain echocardiography, and heart failure management in women, Dr. Nambiar is passionate about early risk stratification.',
    education: [
      'Advanced Cardiac Imaging Fellowship, Johns Hopkins Hospital',
      'DM Cardiology, All India Institute of Medical Sciences (AIIMS)',
      'MD Internal Medicine'
    ],
    awards: ['Young Heart Healer Excellence Award (2023)', 'Fellow of the European Society of Cardiology'],
    specializations: ['Preventive Cardiology', '3D Stress Echocardiography', 'Women’s Heart Health'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-cardio-3',
    name: 'Dr. Julian Rossi',
    title: 'Cardiac Electrophysiologist & Arrhythmia Specialist',
    departmentId: 'cardiology',
    departmentName: 'Cardiology & Vascular Surgery',
    qualification: 'MD, FHRS (Stanford University)',
    experienceYears: 14,
    rating: 4.8,
    reviewCount: 198,
    consultationFee: 165,
    gender: 'male',
    availableDays: ['Tue', 'Wed', 'Thu'],
    timeSlots: ['10:00 AM', '11:30 AM', '03:00 PM', '04:30 PM'],
    languages: ['English', 'Italian', 'Spanish'],
    bio: 'Dr. Rossi leads the cardiac rhythm disorders clinic. He has extensive expertise in catheter radiofrequency ablation, cryoballoon ablation for atrial fibrillation, and biventricular pacemaker implantation.',
    education: [
      'Clinical Cardiac Electrophysiology Fellowship, Stanford Medical Center',
      'MD Internal Medicine, University of Milan'
    ],
    awards: ['Heart Rhythm Society Rising Star Recognition', 'Excellence in Arrhythmia Ablation (2025)'],
    specializations: ['Atrial Fibrillation Ablation', 'Pacemakers & ICDs', 'Syncope Evaluation'],
    acceptingNewPatients: true,
    telehealthAvailable: false
  },

  // --- NEUROLOGY (3 doctors) ---
  {
    id: 'doc-neuro-1',
    name: 'Dr. Sarah Chen',
    title: 'Chief of Neurology & Comprehensive Stroke Director',
    departmentId: 'neurology',
    departmentName: 'Neurology & Neurosurgery',
    qualification: 'MD, PhD, FAAN (UCSF Medical Center)',
    experienceYears: 20,
    rating: 5.0,
    reviewCount: 412,
    consultationFee: 175,
    gender: 'female',
    availableDays: ['Mon', 'Tue', 'Wed', 'Fri'],
    timeSlots: ['08:30 AM', '10:00 AM', '01:30 PM', '03:00 PM'],
    languages: ['English', 'Mandarin'],
    bio: 'Dr. Chen is an authority on cerebrovascular stroke intervention and neuro-critical care. She was instrumental in establishing WeCare’s "Door-to-Needle < 25 Minutes" hyperacute stroke protocol.',
    education: [
      'Vascular Neurology Fellowship, UCSF Medical Center',
      'MD & PhD in Neurobiology, Columbia University'
    ],
    awards: ['American Academy of Neurology Fellow of Distinction', 'Global Stroke Innovation Trophy (2024)'],
    specializations: ['Hyperacute Stroke Interventions', 'Transient Ischemic Attack (TIA)', 'Cerebral Aneurysms'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-neuro-2',
    name: 'Dr. David Vance',
    title: 'Senior Neurosurgeon & Minimally Invasive Spine Lead',
    departmentId: 'neurology',
    departmentName: 'Neurology & Neurosurgery',
    qualification: 'MD, FACS, FAANS (Mayo Clinic)',
    experienceYears: 18,
    rating: 4.9,
    reviewCount: 310,
    consultationFee: 195,
    gender: 'male',
    availableDays: ['Tue', 'Thu', 'Sat'],
    timeSlots: ['09:00 AM', '11:00 AM', '02:00 PM', '04:00 PM'],
    languages: ['English'],
    bio: 'Dr. Vance focuses on cranial base surgery, computer-guided awake brain tumor resection, and endoscopic spinal decompression, preserving nervous system function and accelerating recovery.',
    education: [
      'Complex Spine & Cranial Fellowship, Mayo Clinic Rochester',
      'Neurosurgery Residency, Johns Hopkins'
    ],
    awards: ['North American Spine Society Pioneer Award', 'Surgical Luminary Medal (2025)'],
    specializations: ['Endoscopic Spine Surgery', 'Glioma & Meningioma Resection', 'Trigeminal Neuralgia'],
    acceptingNewPatients: true,
    telehealthAvailable: false
  },
  {
    id: 'doc-neuro-3',
    name: 'Dr. Priyanshi Patel',
    title: 'Consultant Neurologist & Movement Disorder Specialist',
    departmentId: 'neurology',
    departmentName: 'Neurology & Neurosurgery',
    qualification: 'MD, DM Neurology (Oxford Medical School)',
    experienceYears: 12,
    rating: 4.8,
    reviewCount: 184,
    consultationFee: 145,
    gender: 'female',
    availableDays: ['Mon', 'Wed', 'Thu', 'Fri'],
    timeSlots: ['10:00 AM', '11:30 AM', '02:30 PM', '03:45 PM'],
    languages: ['English', 'Gujarati', 'Hindi'],
    bio: 'Dr. Patel focuses on neurological degenerative conditions including Parkinson’s disease, dystonia, migraine management with Botox therapy, and memory impairment evaluations.',
    education: [
      'Clinical Movement Disorders Fellowship, Oxford University Hospitals',
      'MD Neurology, King’s College London'
    ],
    awards: ['Excellence in Neurodegenerative Research', 'International Parkinson’s Society Merit'],
    specializations: ['Parkinson’s Disease & Tremors', 'Chronic Migraine Therapeutics', 'Memory & Dementia Evaluation'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },

  // --- ORTHOPEDICS (3 doctors) ---
  {
    id: 'doc-ortho-1',
    name: 'Dr. Robert Keller',
    title: 'Chief of Orthopedics & Robotic Arthroplasty Director',
    departmentId: 'orthopedics',
    departmentName: 'Orthopedics & Joint Replacement',
    qualification: 'MD, FAAOS (Hospital for Special Surgery, NYC)',
    experienceYears: 22,
    rating: 4.9,
    reviewCount: 460,
    consultationFee: 170,
    gender: 'male',
    availableDays: ['Mon', 'Wed', 'Fri'],
    timeSlots: ['08:30 AM', '10:00 AM', '11:30 AM', '02:00 PM'],
    languages: ['English', 'German'],
    bio: 'Dr. Keller is renowned for robotic arm-assisted total knee and hip replacements. Having performed over 4,000 joint reconstructions, his patients benefit from high precision alignment and rapid walking on day one.',
    education: [
      'Adult Reconstruction Fellowship, Hospital for Special Surgery',
      'Orthopedic Surgery Residency, Cleveland Clinic',
      'MD, University of Pennsylvania'
    ],
    awards: ['Knee Society Master Surgeon Recognition', 'Top Orthopedic Surgeon (2023, 2024, 2025)'],
    specializations: ['Robotic Knee Replacement', 'Direct Anterior Hip Arthroplasty', 'Revision Joint Surgery'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-ortho-2',
    name: 'Dr. Anita Desai',
    title: 'Senior Sports Medicine Surgeon & Arthroscopy Lead',
    departmentId: 'orthopedics',
    departmentName: 'Orthopedics & Joint Replacement',
    qualification: 'MD, DNB Ortho, Dip. Sports Med (IOC)',
    experienceYears: 15,
    rating: 4.8,
    reviewCount: 275,
    consultationFee: 150,
    gender: 'female',
    availableDays: ['Tue', 'Thu', 'Sat'],
    timeSlots: ['09:00 AM', '10:30 AM', '01:30 PM', '03:30 PM'],
    languages: ['English', 'Hindi', 'Marathi'],
    bio: 'Team consultant to national athletic associations, Dr. Desai specializes in keyhole reconstruction of torn ACL, PCL, rotator cuff ligaments, and recurrent shoulder dislocations.',
    education: [
      'Sports Orthopedics Fellowship, Steadman Clinic Colorado',
      'IOC Diploma in Sports Medicine'
    ],
    awards: ['National Sports Orthopedic Specialist of the Year', 'Excellence in Minimally Invasive Arthroscopy'],
    specializations: ['ACL & Ligament Reconstruction', 'Shoulder Labrum Repair', 'Cartilage Restoration'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-ortho-3',
    name: 'Dr. Michael Chang',
    title: 'Consultant Orthopedic Spine & Pediatric Deformity Surgeon',
    departmentId: 'orthopedics',
    departmentName: 'Orthopedics & Joint Replacement',
    qualification: 'MD, FRCS Ortho (Toronto General Hospital)',
    experienceYears: 13,
    rating: 4.8,
    reviewCount: 168,
    consultationFee: 160,
    gender: 'male',
    availableDays: ['Mon', 'Tue', 'Thu'],
    timeSlots: ['10:00 AM', '11:30 AM', '03:00 PM', '04:30 PM'],
    languages: ['English', 'Cantonese'],
    bio: 'Dr. Chang specializes in pediatric musculoskeletal deformities, scoliosis correction, and complex pelvic and acetabular trauma reconstructions.',
    education: [
      'Pediatric Orthopedic Fellowship, SickKids Hospital Toronto',
      'MD, McGill University'
    ],
    awards: ['Pediatric Orthopedic Society Innovator Award', 'Young Surgeon Humanitarian Citation'],
    specializations: ['Scoliosis & Spinal Curvature', 'Pelvic Trauma Reconstructions', 'Pediatric Fracture Care'],
    acceptingNewPatients: true,
    telehealthAvailable: false
  },

  // --- ONCOLOGY (3 doctors) ---
  {
    id: 'doc-onco-1',
    name: 'Dr. Elizabeth Thorne',
    title: 'Director of Medical Oncology & Molecular Therapeutics',
    departmentId: 'oncology',
    departmentName: 'Oncology & Comprehensive Cancer Center',
    qualification: 'MD, PhD, FASCO (Memorial Sloan Kettering)',
    experienceYears: 21,
    rating: 4.9,
    reviewCount: 340,
    consultationFee: 185,
    gender: 'female',
    availableDays: ['Mon', 'Tue', 'Thu', 'Fri'],
    timeSlots: ['09:00 AM', '11:00 AM', '02:00 PM', '03:30 PM'],
    languages: ['English', 'French'],
    bio: 'Dr. Thorne guides cancer patients with genomic tumor profiling, targeted immunotherapies, and clinical trials. She chairs the Hospital Tumor Board and is dedicated to preserving quality of life.',
    education: [
      'Medical Oncology Fellowship, Memorial Sloan Kettering Cancer Center',
      'MD & PhD in Molecular Oncology, Yale School of Medicine'
    ],
    awards: ['ASCO Lifetime Achievement in Patient Advocacy', 'Excellence in Immunotherapy Research (2024)'],
    specializations: ['Immunotherapy & Targeted Biologics', 'Breast & Gynecologic Cancers', 'Lung Cancer Care'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-onco-2',
    name: 'Dr. Vikram Malhotra',
    title: 'Senior Surgical Oncologist & Peritoneal Surface Lead',
    departmentId: 'oncology',
    departmentName: 'Oncology & Comprehensive Cancer Center',
    qualification: 'MS, MCh Surgical Oncology, FACS (MD Anderson)',
    experienceYears: 17,
    rating: 4.9,
    reviewCount: 230,
    consultationFee: 175,
    gender: 'male',
    availableDays: ['Wed', 'Fri', 'Sat'],
    timeSlots: ['08:30 AM', '10:30 AM', '01:30 PM', '03:00 PM'],
    languages: ['English', 'Hindi', 'Punjabi'],
    bio: 'Dr. Malhotra has dedicated his career to complex gastrointestinal oncologic resections, cytoreductive surgery with HIPEC (heated intraperitoneal chemotherapy), and robotic head and neck surgeries.',
    education: [
      'Surgical Oncology Fellowship, MD Anderson Cancer Center',
      'MCh Surgical Oncology, Tata Memorial Hospital'
    ],
    awards: ['Distinguished Surgical Oncologist of the Year (2023)', 'Pioneer in HIPEC Peritoneal Cancer Treatment'],
    specializations: ['Gastrointestinal Surgical Oncology', 'Cytoreductive Surgery & HIPEC', 'Head & Neck Oncology'],
    acceptingNewPatients: true,
    telehealthAvailable: false
  },
  {
    id: 'doc-onco-3',
    name: 'Dr. Claire Dubois',
    title: 'Consultant Radiation Oncologist & CyberKnife Specialist',
    departmentId: 'oncology',
    departmentName: 'Oncology & Comprehensive Cancer Center',
    qualification: 'MD, FASTRO (Institut Curie, Paris / Johns Hopkins)',
    experienceYears: 14,
    rating: 4.8,
    reviewCount: 190,
    consultationFee: 160,
    gender: 'female',
    availableDays: ['Mon', 'Wed', 'Thu'],
    timeSlots: ['09:30 AM', '11:00 AM', '02:00 PM', '04:00 PM'],
    languages: ['English', 'French', 'Spanish'],
    bio: 'Dr. Dubois specializes in image-guided stereotactic body radiation therapy (SBRT), minimizing exposure to healthy surrounding organs and targeting tumors with sub-millimeter precision.',
    education: [
      'Radiation Oncology Fellowship, Johns Hopkins Hospital',
      'MD, Sorbonne University Paris'
    ],
    awards: ['European Society for Radiotherapy & Oncology Young Investigator', 'Clinical Precision Care Merit'],
    specializations: ['Stereotactic Radiosurgery (SRS/SBRT)', 'Prostate & Brain Radiation', 'Image-Guided Radiotherapy'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },

  // --- PEDIATRICS (3 doctors) ---
  {
    id: 'doc-pedia-1',
    name: 'Dr. Sophia Martinez',
    title: 'Chief of Pediatrics & Pediatric Pulmonology Specialist',
    departmentId: 'pediatrics',
    departmentName: 'Pediatrics & Neonatal Care',
    qualification: 'MD, FAAP (Children’s Hospital of Philadelphia)',
    experienceYears: 19,
    rating: 5.0,
    reviewCount: 520,
    consultationFee: 140,
    gender: 'female',
    availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    timeSlots: ['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:30 PM'],
    languages: ['English', 'Spanish'],
    bio: 'Dr. Martinez is beloved by kids and trusted by parents across the region. She treats childhood asthma, chronic allergies, developmental concerns, and provides proactive wellness checks.',
    education: [
      'Pediatric Pulmonology Fellowship, CHOP (Philadelphia)',
      'Pediatrics Residency, Boston Children’s Hospital',
      'MD, Stanford University'
    ],
    awards: ['Top Pediatrician of the Year (2024, 2025)', 'Compassionate Doctor Recognition Award'],
    specializations: ['Childhood Asthma & Allergies', 'Developmental Milestone Checks', 'Pediatric Wellness'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-pedia-2',
    name: 'Dr. Kenneth O’Connor',
    title: 'Director of Neonatology & Level III NICU Lead',
    departmentId: 'pediatrics',
    departmentName: 'Pediatrics & Neonatal Care',
    qualification: 'MD, FAAP, FRCPCH (Great Ormond Street Hospital, London)',
    experienceYears: 18,
    rating: 4.9,
    reviewCount: 278,
    consultationFee: 160,
    gender: 'male',
    availableDays: ['Mon', 'Wed', 'Fri', 'Sat'],
    timeSlots: ['08:30 AM', '10:30 AM', '01:30 PM', '03:00 PM'],
    languages: ['English', 'Irish'],
    bio: 'Dr. O’Connor directs the neonatal intensive care unit, managing critical pre-term infants and congenital cardiorespiratory stabilization with gentle, round-the-clock family-centered care.',
    education: [
      'Neonatal-Perinatal Medicine Fellowship, GOSH London',
      'MD, Trinity College Dublin'
    ],
    awards: ['Perinatal Care Champion Medal', 'Exceptional Neonatal Survival Outcomes Citation'],
    specializations: ['Extremely Low Birth Weight Care', 'Neonatal Hypothermia Therapy', 'Congenital Newborn Disorders'],
    acceptingNewPatients: true,
    telehealthAvailable: false
  },
  {
    id: 'doc-pedia-3',
    name: 'Dr. Aisha Bello',
    title: 'Consultant Pediatrician & Adolescent Health Specialist',
    departmentId: 'pediatrics',
    departmentName: 'Pediatrics & Neonatal Care',
    qualification: 'MBBS, MD Pediatrics, FAAP (Northwestern University)',
    experienceYears: 11,
    rating: 4.9,
    reviewCount: 215,
    consultationFee: 130,
    gender: 'female',
    availableDays: ['Tue', 'Thu', 'Sat'],
    timeSlots: ['09:30 AM', '11:30 AM', '02:30 PM', '04:00 PM'],
    languages: ['English', 'Arabic', 'Yoruba'],
    bio: 'Dr. Bello focuses on pediatric lifestyle medicine, adolescent growth nutrition, childhood diabetes management, and recurring childhood infections.',
    education: [
      'Adolescent Medicine Fellowship, Ann & Robert H. Lurie Children’s Hospital',
      'MD Pediatrics, Northwestern Feinberg School'
    ],
    awards: ['Community Child Health Champion', 'Excellence in Adolescent Guidance'],
    specializations: ['Adolescent Medicine', 'Pediatric Growth & Nutrition', 'Preventive Vaccinations'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },

  // --- OBGYN (3 doctors) ---
  {
    id: 'doc-obgyn-1',
    name: 'Dr. Rachel Greenberg',
    title: 'Head of Women’s Health & Maternal-Fetal Medicine Director',
    departmentId: 'obgyn',
    departmentName: 'Obstetrics & Gynecology (Women’s Health)',
    qualification: 'MD, FACOG (Columbia University Medical Center)',
    experienceYears: 23,
    rating: 4.9,
    reviewCount: 490,
    consultationFee: 170,
    gender: 'female',
    availableDays: ['Mon', 'Tue', 'Thu', 'Fri'],
    timeSlots: ['09:00 AM', '10:30 AM', '01:30 PM', '03:00 PM'],
    languages: ['English', 'Hebrew'],
    bio: 'Dr. Greenberg has safely delivered over 5,000 babies and specializes in high-risk pregnancies, multiple gestations, and preeclampsia management with holistic compassionate guidance.',
    education: [
      'Maternal-Fetal Medicine Fellowship, Columbia Presbyterian',
      'Ob/Gyn Residency, Mount Sinai Hospital NY',
      'MD, NYU Grossman School of Medicine'
    ],
    awards: ['Distinguished Obstetrician of the Decade', 'Patient Choice Compassion Award (2024)'],
    specializations: ['High-Risk Pregnancies', 'Twin & Triplet Gestations', 'Prenatal Diagnostic Ultrasound'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-obgyn-2',
    name: 'Dr. Sunita Rao',
    title: 'Senior Consultant Laparoscopic & Robotic Gynecologist',
    departmentId: 'obgyn',
    departmentName: 'Obstetrics & Gynecology (Women’s Health)',
    qualification: 'MD, MS OB-GYN, FMAS (Cleveland Clinic)',
    experienceYears: 16,
    rating: 4.9,
    reviewCount: 310,
    consultationFee: 155,
    gender: 'female',
    availableDays: ['Mon', 'Wed', 'Fri', 'Sat'],
    timeSlots: ['09:30 AM', '11:00 AM', '02:00 PM', '03:30 PM'],
    languages: ['English', 'Hindi', 'Kannada'],
    bio: 'Dr. Rao is an expert in fertility-sparing robotic myomectomy for large uterine fibroids, advanced stage-4 endometriosis excision, and minimally invasive laparoscopic surgery.',
    education: [
      'Minimally Invasive Gynecologic Surgery Fellowship, Cleveland Clinic',
      'MS Obstetrics & Gynecology'
    ],
    awards: ['AAGL Golden Laparoscope Recognition', 'Excellence in Endometriosis Eradication'],
    specializations: ['Robotic Fibroid Myomectomy', 'Deep Infiltrating Endometriosis', 'PCOS Management'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-obgyn-3',
    name: 'Dr. Emily Watson',
    title: 'Consultant Obstetrician & Menopause Wellness Lead',
    departmentId: 'obgyn',
    departmentName: 'Obstetrics & Gynecology (Women’s Health)',
    qualification: 'MD, MRCOG, NCMP (University of Edinburgh)',
    experienceYears: 12,
    rating: 4.8,
    reviewCount: 225,
    consultationFee: 140,
    gender: 'female',
    availableDays: ['Tue', 'Thu', 'Fri'],
    timeSlots: ['10:00 AM', '11:30 AM', '02:30 PM', '04:00 PM'],
    languages: ['English'],
    bio: 'Dr. Watson provides thoughtful natural birth planning, gentle postpartum recovery counseling, and comprehensive perimenopause hormone replacement therapies.',
    education: [
      'Advanced Reproductive Health Fellowship, Edinburgh Royal Infirmary',
      'Certified Menopause Practitioner (NAMS)'
    ],
    awards: ['Women’s Wellness Advocate of the Year', 'Excellence in Natural Birthing Support'],
    specializations: ['Gentle Birth Planning & Postpartum Care', 'Hormone Optimization & Menopause', 'Cervical Health'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },

  // --- GASTROENTEROLOGY (3 doctors) ---
  {
    id: 'doc-gastro-1',
    name: 'Dr. Farhan Al-Mansoor',
    title: 'Chief of Gastroenterology & Advanced Endoscopy Director',
    departmentId: 'gastroenterology',
    departmentName: 'Gastroenterology & Liver Center',
    qualification: 'MD, AGAF, FASGE (University of Chicago Medicine)',
    experienceYears: 22,
    rating: 4.9,
    reviewCount: 370,
    consultationFee: 165,
    gender: 'male',
    availableDays: ['Mon', 'Tue', 'Thu', 'Fri'],
    timeSlots: ['08:30 AM', '10:00 AM', '01:30 PM', '03:00 PM'],
    languages: ['English', 'Arabic'],
    bio: 'Dr. Al-Mansoor is an internationally acknowledged leader in therapeutic ERCP, endoscopic ultrasound (EUS) for pancreatic lesions, and third-space endoscopy for achalasia (POEM).',
    education: [
      'Advanced Interventional Endoscopy Fellowship, University of Chicago',
      'Gastroenterology Fellowship, Baylor College of Medicine',
      'MD, American University of Beirut'
    ],
    awards: ['American Gastroenterological Association Fellow', 'Pioneer in Biliary Endoscopy Trophy'],
    specializations: ['Therapeutic ERCP & EUS', 'Pancreatic & Biliary Diseases', 'Large Polyp Resections'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-gastro-2',
    name: 'Dr. Linda Zhao',
    title: 'Director of Hepatology & Liver Transplant Medicine',
    departmentId: 'gastroenterology',
    departmentName: 'Gastroenterology & Liver Center',
    qualification: 'MD, PhD, FAASLD (UCLA Health)',
    experienceYears: 16,
    rating: 4.9,
    reviewCount: 260,
    consultationFee: 160,
    gender: 'female',
    availableDays: ['Mon', 'Wed', 'Fri'],
    timeSlots: ['09:00 AM', '11:00 AM', '02:00 PM', '03:30 PM'],
    languages: ['English', 'Mandarin'],
    bio: 'Dr. Zhao directs the Fatty Liver & Viral Hepatitis Clinic. Her research in non-invasive liver fibrosis staging and metabolic dysfunction-associated steatotic liver disease has altered clinical guidelines.',
    education: [
      'Transplant Hepatology Fellowship, UCLA Dumont-UCLA Liver Center',
      'MD & PhD, Washington University in St. Louis'
    ],
    awards: ['AASLD Liver Scholar Recognition', 'Clinical Hepatology Excellence Award'],
    specializations: ['Fatty Liver Disease (NASH/MASH)', 'Cirrhosis Management', 'Hepatitis B & C Therapies'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-gastro-3',
    name: 'Dr. Carlos Morales',
    title: 'Consultant Gastroenterologist & IBD Specialist',
    departmentId: 'gastroenterology',
    departmentName: 'Gastroenterology & Liver Center',
    qualification: 'MD, FACG (Mount Sinai Medical Center)',
    experienceYears: 13,
    rating: 4.8,
    reviewCount: 195,
    consultationFee: 145,
    gender: 'male',
    availableDays: ['Tue', 'Wed', 'Sat'],
    timeSlots: ['09:30 AM', '11:00 AM', '02:30 PM', '04:00 PM'],
    languages: ['English', 'Spanish'],
    bio: 'Dr. Morales focuses on personalized biologic treatment of Crohn’s disease, ulcerative colitis, microscopic colitis, and resistant irritable bowel syndrome.',
    education: [
      'Inflammatory Bowel Disease Fellowship, Mount Sinai NY',
      'MD, University of Miami Miller School of Medicine'
    ],
    awards: ['Crohn’s & Colitis Foundation Clinical Honor', 'Top Young Gastroenterologist (2024)'],
    specializations: ['Crohn’s Disease & Ulcerative Colitis', 'Refractory GERD', 'Screening Colonoscopy'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },

  // --- PULMONOLOGY (3 doctors) ---
  {
    id: 'doc-pulmo-1',
    name: 'Dr. Jonathan Briggs',
    title: 'Chief of Pulmonary Medicine & Interventional Pulmonologist',
    departmentId: 'pulmonology',
    departmentName: 'Pulmonology & Respiratory Care',
    qualification: 'MD, FCCP (National Jewish Health, Denver)',
    experienceYears: 23,
    rating: 4.9,
    reviewCount: 390,
    consultationFee: 170,
    gender: 'male',
    availableDays: ['Mon', 'Tue', 'Thu', 'Fri'],
    timeSlots: ['09:00 AM', '10:30 AM', '02:00 PM', '03:30 PM'],
    languages: ['English'],
    bio: 'Dr. Briggs is a leading authority on robotic bronchoscopy for early lung nodule diagnosis, severe chronic obstructive pulmonary disease (COPD), and interventional pleural procedures.',
    education: [
      'Interventional Pulmonary Fellowship, National Jewish Health',
      'Pulmonary & Critical Care Fellowship, University of Colorado'
    ],
    awards: ['Distinguished Fellow of the American College of Chest Physicians', 'Lung Health Vanguard Award'],
    specializations: ['Robotic Navigational Bronchoscopy', 'Severe COPD & Emphysema', 'Lung Nodule Biopsy'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-pulmo-2',
    name: 'Dr. Fatima Zahra',
    title: 'Director of Sleep Medicine & Critical Care Intensivist',
    departmentId: 'pulmonology',
    departmentName: 'Pulmonology & Respiratory Care',
    qualification: 'MD, FAASM, FCCP (McGill University)',
    experienceYears: 15,
    rating: 4.8,
    reviewCount: 245,
    consultationFee: 155,
    gender: 'female',
    availableDays: ['Mon', 'Wed', 'Fri'],
    timeSlots: ['09:30 AM', '11:00 AM', '01:30 PM', '03:00 PM'],
    languages: ['English', 'French', 'Arabic'],
    bio: 'Dr. Zahra manages complex sleep-disordered breathing, narcolepsy, nocturnal hypoventilation, and leads critical care weaning in the respiratory intermediate unit.',
    education: [
      'Sleep Medicine Fellowship, Harvard Medical School / Beth Israel',
      'MD Pulmonary Medicine, McGill University'
    ],
    awards: ['Sleep Health Clinical Leadership Award (2024)', 'Excellence in Critical Care Medicine'],
    specializations: ['Obstructive Sleep Apnea (OSA)', 'Insomnia & Restless Legs Syndrome', 'ICU Mechanical Ventilation'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  },
  {
    id: 'doc-pulmo-3',
    name: 'Dr. Patrick Hayes',
    title: 'Consultant Pulmonologist & Interstitial Lung Disease Specialist',
    departmentId: 'pulmonology',
    departmentName: 'Pulmonology & Respiratory Care',
    qualification: 'MB BCh BAO, MD, MRCP (Royal Brompton Hospital, London)',
    experienceYears: 13,
    rating: 4.8,
    reviewCount: 172,
    consultationFee: 150,
    gender: 'male',
    availableDays: ['Tue', 'Thu', 'Sat'],
    timeSlots: ['10:00 AM', '11:30 AM', '02:30 PM', '04:00 PM'],
    languages: ['English'],
    bio: 'Dr. Hayes has expertise in interstitial lung disease, idiopathic pulmonary fibrosis, sarcoidosis, and occupational dust exposures, utilizing antifibrotic regimens to slow disease progression.',
    education: [
      'Interstitial Lung Disease Fellowship, Royal Brompton Hospital London',
      'Medical Degree, University College Dublin'
    ],
    awards: ['Pulmonary Fibrosis Research Vanguard Citation', 'Young Chest Physician Recognition'],
    specializations: ['Idiopathic Pulmonary Fibrosis (IPF)', 'Sarcoidosis', 'Post-Pneumonia Lung Healing'],
    acceptingNewPatients: true,
    telehealthAvailable: true
  }
];

export const INITIAL_APPOINTMENTS: Appointment[] = [
  {
    id: 'apt-seed-1',
    referenceCode: 'WCH-94821',
    doctorId: 'doc-cardio-1',
    doctorName: 'Dr. Arthur Sterling',
    doctorTitle: 'Chief of Cardiology',
    departmentId: 'cardiology',
    departmentName: 'Cardiology & Vascular Surgery',
    patientName: 'Eleanor Vance',
    patientEmail: 'eleanor.vance@example.com',
    patientPhone: '+1 (555) 234-8901',
    patientAge: 48,
    patientGender: 'female',
    isExistingPatient: true,
    date: '2026-10-12',
    timeSlot: '10:00 AM',
    consultationType: 'in-person',
    reason: 'Annual cardiovascular risk review and follow-up on resting ECG evaluation.',
    notes: 'Please bring past blood test reports from last 6 months.',
    status: 'confirmed',
    createdAt: '2026-10-02T14:20:00.000Z',
    consultationFee: 180,
    roomNumber: 'Suite 304, Cardio Pavilion'
  }
];

export const ACCREDITATIONS = [
  {
    title: 'JCI Gold Seal of Approval®',
    issuer: 'Joint Commission International',
    year: '2014 – Present',
    description: 'Gold standard global benchmark for hospital patient safety and clinical quality protocols.'
  },
  {
    title: 'NABH Digital Health Exemplar',
    issuer: 'National Accreditation Board for Hospitals',
    year: 'Continuous',
    description: 'Certified excellence in patient-centric care, digital health security, and sterile hospital infection control.'
  },
  {
    title: 'CAP Laboratory Accreditation',
    issuer: 'College of American Pathologists',
    year: 'Accredited',
    description: 'International recognition for laboratory precision across over 1,200 diagnostic pathology parameters.'
  },
  {
    title: 'Magnet® Nursing Excellence',
    issuer: 'American Nurses Credentialing Center',
    year: 'Honored',
    description: 'Recognizing superior bedside nursing ratios, patient compassion scores, and clinical nursing leadership.'
  }
];

export const CARE_STORIES = [
  {
    id: 'story-1',
    patientName: 'Marcus Holloway',
    patientAge: 54,
    condition: 'Complex Multivessel Coronary Blockage',
    doctorName: 'Dr. Arthur Sterling',
    department: 'Cardiology & Vascular Surgery',
    outcome: 'Discharged in 48 hours following robotic hybrid angioplasty. Resumed full marathon training within 3 months.',
    quote: 'The clarity, precision, and human kindness at WeCare Hospitals gave me back my life. From the triage team to Dr. Sterling, every single step felt synchronized and deeply caring.',
    date: 'August 2026'
  },
  {
    id: 'story-2',
    patientName: 'Sarah Jenkins',
    patientAge: 32,
    condition: 'High-Risk Twin Delivery with Preeclampsia',
    doctorName: 'Dr. Rachel Greenberg',
    department: 'Obstetrics & Gynecology',
    outcome: 'Successful delivery of twin boys at 36 weeks with zero neonatal complications in Level III NICU.',
    quote: 'When complications arose at week 34, Dr. Greenberg’s calm expertise and the immediate NICU readiness meant I was never afraid. Our family will forever be grateful to WeCare.',
    date: 'September 2026'
  },
  {
    id: 'story-3',
    patientName: 'David Chen',
    patientAge: 62,
    condition: 'Severe Bilateral Knee Osteoarthritis',
    doctorName: 'Dr. Robert Keller',
    department: 'Orthopedics & Joint Replacement',
    outcome: 'Bilateral robotic knee replacement with pain-free walking by post-op day 2 and full golf swing restored.',
    quote: 'I had avoided surgery for 6 years out of fear of stiffness. Dr. Keller’s robotic technique was practically painless compared to what I expected. I walk completely without pain now.',
    date: 'July 2026'
  }
];

export const HOSPITAL_MILESTONES = [
  {
    year: '2008',
    title: 'Founding of WeCare Health',
    description: 'Established as an 80-bed community hospital dedicated to ethical, affordable tertiary healthcare.'
  },
  {
    year: '2014',
    title: 'First JCI Accreditation',
    description: 'Awarded Joint Commission International accreditation within our first comprehensive assessment cycle.'
  },
  {
    year: '2019',
    title: 'Robotic Surgery & Advanced Heart Wing',
    description: 'Inaugurated dedicated cardiac catheterization suites and multi-specialty da Vinci® robotic surgery theater.'
  },
  {
    year: '2023',
    title: 'Level 1 Trauma & Comprehensive Cancer Center',
    description: 'Expanded to 450 beds with state-of-the-art linear accelerator radiotherapy and 24/7 dedicated acute stroke trauma unit.'
  },
  {
    year: '2026',
    title: 'Connected Health & Next-Gen Precision Medicine',
    description: 'Launched seamless digital appointments, AI-enhanced endoscopy, and genomic-targeted oncology clinics.'
  }
];
